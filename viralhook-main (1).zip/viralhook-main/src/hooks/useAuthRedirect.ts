import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useCredits } from "@/contexts/CreditContext";

const REDIRECT_KEY = "auth_redirect_to";

export function useAuthRedirect() {
  const navigate = useNavigate();
  const { user } = useCredits();

  const setRedirectDestination = useCallback((destination: string) => {
    sessionStorage.setItem(REDIRECT_KEY, destination);
  }, []);

  const getRedirectDestination = useCallback(() => {
    return sessionStorage.getItem(REDIRECT_KEY);
  }, []);

  const clearRedirectDestination = useCallback(() => {
    sessionStorage.removeItem(REDIRECT_KEY);
  }, []);

  const navigateWithAuth = useCallback(
    (destination: string) => {
      if (user) {
        // User is logged in, go directly to destination
        navigate(destination);
      } else {
        // Store destination and redirect to login
        setRedirectDestination(destination);
        navigate("/auth");
      }
    },
    [user, navigate, setRedirectDestination]
  );

  return {
    setRedirectDestination,
    getRedirectDestination,
    clearRedirectDestination,
    navigateWithAuth,
    isAuthenticated: !!user,
  };
}
