import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import { PlanType } from "@/lib/creditCosts";

interface CreditContextType {
  credits: number;
  loading: boolean;
  user: User | null;
  planType: PlanType;
  refreshCredits: () => Promise<void>;
  deductCredits: (amount: number) => Promise<boolean>;
  hasCredits: boolean;
  showUpgradeModal: boolean;
  setShowUpgradeModal: (show: boolean) => void;
  isPremiumPlan: boolean;
}

const CreditContext = createContext<CreditContextType | undefined>(undefined);

export function CreditProvider({ children }: { children: React.ReactNode }) {
  const [credits, setCredits] = useState(0);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [planType, setPlanType] = useState<PlanType>("free");
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);

  const refreshCredits = useCallback(async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from("profiles")
      .select("credits, plan_type")
      .eq("id", user.id)
      .single();
    
    if (!error && data) {
      setCredits(data.credits);
      setPlanType((data.plan_type as PlanType) || "free");
      // Auto-show upgrade modal when credits hit 0
      if (data.credits <= 0) {
        setShowUpgradeModal(true);
      }
    }
  }, [user]);

  const deductCredits = useCallback(async (amount: number): Promise<boolean> => {
    if (!user) return false;
    
    const { data, error } = await supabase.rpc("deduct_credits", {
      user_id: user.id,
      amount,
    });
    
    if (error || data === -1) {
      setShowUpgradeModal(true);
      return false;
    }
    
    setCredits(data);
    // Auto-show upgrade modal when credits hit 0
    if (data <= 0) {
      setShowUpgradeModal(true);
    }
    return true;
  }, [user]);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null);
        if (!session?.user) {
          setCredits(0);
          setPlanType("free");
          setLoading(false);
        }
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (!session?.user) {
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      setLoading(true);
      refreshCredits().finally(() => setLoading(false));
    }
  }, [user, refreshCredits]);

  // Premium plans (₹499 Pro or ₹999 Elite) have full access
  const isPremiumPlan = planType === "pro" || planType === "elite";

  return (
    <CreditContext.Provider
      value={{
        credits,
        loading,
        user,
        planType,
        refreshCredits,
        deductCredits,
        hasCredits: credits > 0,
        showUpgradeModal,
        setShowUpgradeModal,
        isPremiumPlan,
      }}
    >
      {children}
    </CreditContext.Provider>
  );
}

export function useCredits() {
  const context = useContext(CreditContext);
  if (context === undefined) {
    throw new Error("useCredits must be used within a CreditProvider");
  }
  return context;
}
