import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { 
  Video, Loader2, AlertCircle, Copy, Check, Lock, Crown,
  Play, Clock, TrendingUp, TrendingDown, Eye, MessageSquare,
  Lightbulb, Target, Sparkles, Youtube, Instagram, Facebook
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AppHeader } from "@/components/AppHeader";
import { useCredits } from "@/contexts/CreditContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { CREDIT_COSTS } from "@/lib/creditCosts";
import { UpgradePopup } from "@/components/UpgradePopup";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Platform = "youtube" | "instagram" | "facebook";

interface VideoAnalysis {
  videoSnapshot: {
    platform: string;
    format: string;
    duration: string;
    relativePerformance: string;
    engagementQuality: string;
    title?: string;
    viewCount?: string;
    uploadDate?: string;
  };
  hookAnalysis: {
    isHookClear: string;
    curiosityLevel: string;
    scrollAwayReasons: string[];
    improvements: string[];
  };
  contentFlow: {
    attentionDropPoints: string[];
    pacingIssues: string[];
    problemAreas: string[];
  };
  titleCaptionReview: {
    matchScore: string;
    clickMismatchIssues: string[];
    seoIssues: string[];
  };
  visualFeedback: {
    lengthVsBestPractice: string;
    textReadability: string;
    energyLevel: string;
    formatMistakes: string[];
  };
  improvementGuide: {
    hookRewrite: string;
    pacingTips: string[];
    whatToCut: string[];
    whatToAdd: string[];
    idealLength: string;
  };
  nextVideoRecommendations: Array<{
    title: string;
    hookAngle: string;
    whyItWillPerform: string;
    platformAdvice: string;
  }>;
}

const ANALYSIS_COST = CREDIT_COSTS.videoAnalysis || 30;

const platformOptions = [
  { value: "youtube", label: "YouTube", icon: Youtube },
  { value: "instagram", label: "Instagram", icon: Instagram },
  { value: "facebook", label: "Facebook", icon: Facebook },
];

export default function VideoAnalyze() {
  const { user, credits, refreshCredits, planType } = useCredits();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [videoUrl, setVideoUrl] = useState("");
  const [platform, setPlatform] = useState<Platform>("youtube");
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<VideoAnalysis | null>(null);
  const [showUpgradePopup, setShowUpgradePopup] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Access control: ₹199+ plans only
  const hasAccess = planType === "creator" || planType === "pro" || planType === "elite";

  const handleAnalyze = async () => {
    if (!user) {
      navigate("/auth");
      return;
    }

    if (!hasAccess) {
      setShowUpgradePopup(true);
      return;
    }

    if (credits < ANALYSIS_COST) {
      setShowUpgradePopup(true);
      return;
    }

    if (!videoUrl.trim()) {
      toast({
        title: "Video URL Required",
        description: "Please enter a valid video URL",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setAnalysis(null);

    try {
      const { data, error } = await supabase.functions.invoke("analyze-video", {
        body: { 
          videoUrl: videoUrl.trim(),
          platform,
          userId: user.id,
        },
      });

      if (error) throw error;

      if (data.error) {
        toast({
          title: "Analysis Failed",
          description: data.error,
          variant: "destructive",
        });
        return;
      }

      setAnalysis(data.analysis);
      await refreshCredits();

      toast({
        title: "Analysis Complete!",
        description: `${ANALYSIS_COST} credits used. Your video has been analyzed.`,
      });
    } catch (error) {
      console.error("Video analysis error:", error);
      toast({
        title: "Analysis Failed",
        description: "Could not analyze video. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    toast({ title: "Copied to clipboard!" });
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <AppHeader />
        <main className="container px-4 py-12 text-center">
          <p className="text-muted-foreground">Please log in to use this tool.</p>
          <Button onClick={() => navigate("/auth")} className="mt-4">
            Login
          </Button>
        </main>
      </div>
    );
  }

  // Show locked state for ₹49 plan
  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-background">
        <AppHeader />
        <main className="container px-4 py-12">
          <div className="max-w-lg mx-auto text-center">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-amber-500/10 flex items-center justify-center">
              <Lock className="w-10 h-10 text-amber-500" />
            </div>
            <h1 className="text-3xl font-bold mb-4">Premium Feature</h1>
            <p className="text-muted-foreground mb-6">
              Video Analyze & Improvement Guide is available on the <strong>Creator (₹199)</strong>, <strong>Pro (₹499)</strong>, and <strong>Elite (₹999)</strong> plans.
            </p>
            <Button variant="glow" onClick={() => navigate("/buy-credits")}>
              <Crown className="w-4 h-4 mr-2" />
              Upgrade to ₹199+ Plan
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
              <Video className="w-4 h-4" />
              <span className="text-sm font-medium">Video Analyze & Improvement Guide</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Analyze Any Video Performance
            </h1>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Get detailed insights on why your video performed the way it did, and actionable improvements for your next videos.
            </p>
            <p className="text-sm text-primary mt-2">
              Cost: {ANALYSIS_COST} credits per analysis • Your balance: {credits} credits
            </p>
          </div>

          {/* Input Section */}
          <div className="p-6 rounded-2xl bg-card/50 border border-border/50 mb-8">
            <div className="grid md:grid-cols-[1fr_200px] gap-4 mb-4">
              <div>
                <Label htmlFor="videoUrl">Video URL</Label>
                <Input
                  id="videoUrl"
                  placeholder="https://youtube.com/watch?v=... or Instagram/Facebook URL"
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  className="mt-1 bg-secondary/50"
                />
              </div>
              <div>
                <Label>Platform</Label>
                <Select value={platform} onValueChange={(v) => setPlatform(v as Platform)}>
                  <SelectTrigger className="mt-1 bg-secondary/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {platformOptions.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        <div className="flex items-center gap-2">
                          <opt.icon className="w-4 h-4" />
                          {opt.label}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button
              variant="glow"
              className="w-full"
              onClick={handleAnalyze}
              disabled={loading || !videoUrl.trim() || credits < ANALYSIS_COST}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing Video...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Analyze Video ({ANALYSIS_COST} credits)
                </>
              )}
            </Button>

            {credits < ANALYSIS_COST && (
              <p className="text-sm text-destructive text-center mt-2">
                Not enough credits. <button onClick={() => navigate("/buy-credits")} className="underline">Buy more credits</button>
              </p>
            )}
          </div>

          {/* Trust Message */}
          {analysis && (
            <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/30 mb-8">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-amber-200">
                  This analysis is based on public information and AI pattern intelligence.
                  Private analytics like exact watch time are not accessible.
                </p>
              </div>
            </div>
          )}

          {/* Analysis Results */}
          {analysis && (
            <div className="space-y-6">
              {/* Section 1: Video Snapshot */}
              <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Play className="w-5 h-5 text-primary" />
                  1️⃣ Video Snapshot
                </h2>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Platform</p>
                    <p className="font-semibold">{analysis.videoSnapshot.platform}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Format</p>
                    <p className="font-semibold">{analysis.videoSnapshot.format}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Duration</p>
                    <p className="font-semibold">{analysis.videoSnapshot.duration}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Relative Performance</p>
                    <p className={`font-semibold ${
                      analysis.videoSnapshot.relativePerformance === "High" ? "text-green-500" :
                      analysis.videoSnapshot.relativePerformance === "Medium" ? "text-yellow-500" : "text-red-500"
                    }`}>{analysis.videoSnapshot.relativePerformance}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Engagement Quality</p>
                    <p className={`font-semibold ${
                      analysis.videoSnapshot.engagementQuality === "Strong" ? "text-green-500" :
                      analysis.videoSnapshot.engagementQuality === "Average" ? "text-yellow-500" : "text-red-500"
                    }`}>{analysis.videoSnapshot.engagementQuality}</p>
                  </div>
                  {analysis.videoSnapshot.viewCount && (
                    <div className="p-4 rounded-lg bg-secondary/30">
                      <p className="text-sm text-muted-foreground">Views</p>
                      <p className="font-semibold">{analysis.videoSnapshot.viewCount}</p>
                    </div>
                  )}
                </div>
                {analysis.videoSnapshot.title && (
                  <p className="mt-4 text-muted-foreground">
                    <strong>Title:</strong> {analysis.videoSnapshot.title}
                  </p>
                )}
              </div>

              {/* Section 2: Hook Analysis */}
              <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Target className="w-5 h-5 text-primary" />
                  2️⃣ Hook & Opening Analysis
                </h2>
                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Is Hook Clear?</p>
                    <p className="font-semibold">{analysis.hookAnalysis.isHookClear}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Curiosity Level</p>
                    <p className="font-semibold">{analysis.hookAnalysis.curiosityLevel}</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-medium text-red-400 mb-2">Why Users May Scroll Away:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      {analysis.hookAnalysis.scrollAwayReasons.map((reason, i) => (
                        <li key={i}>{reason}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-green-400 mb-2">What to Change:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      {analysis.hookAnalysis.improvements.map((imp, i) => (
                        <li key={i}>{imp}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Section 3: Content Flow */}
              <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  3️⃣ Content Flow & Retention Patterns
                </h2>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium text-amber-400 mb-2">Attention Drop Points (Inferred):</p>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      {analysis.contentFlow.attentionDropPoints.map((point, i) => (
                        <li key={i}>{point}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-amber-400 mb-2">Pacing Issues:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      {analysis.contentFlow.pacingIssues.map((issue, i) => (
                        <li key={i}>{issue}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Section 4: Title/Caption Review */}
              <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-primary" />
                  4️⃣ Title / Caption / Hashtag Review
                </h2>
                <div className="p-4 rounded-lg bg-secondary/30 mb-4">
                  <p className="text-sm text-muted-foreground">Match Score</p>
                  <p className="font-semibold">{analysis.titleCaptionReview.matchScore}</p>
                </div>
                <div className="space-y-3">
                  {analysis.titleCaptionReview.clickMismatchIssues.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-red-400 mb-2">Click Mismatch Issues:</p>
                      <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                        {analysis.titleCaptionReview.clickMismatchIssues.map((issue, i) => (
                          <li key={i}>{issue}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {analysis.titleCaptionReview.seoIssues.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-amber-400 mb-2">SEO Issues:</p>
                      <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                        {analysis.titleCaptionReview.seoIssues.map((issue, i) => (
                          <li key={i}>{issue}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </div>

              {/* Section 5: Visual Feedback */}
              <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Eye className="w-5 h-5 text-primary" />
                  5️⃣ Visual & Format Feedback
                </h2>
                <div className="grid md:grid-cols-3 gap-4 mb-4">
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Length vs Best Practice</p>
                    <p className="font-semibold text-sm">{analysis.visualFeedback.lengthVsBestPractice}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Text Readability</p>
                    <p className="font-semibold">{analysis.visualFeedback.textReadability}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-secondary/30">
                    <p className="text-sm text-muted-foreground">Energy Level</p>
                    <p className="font-semibold">{analysis.visualFeedback.energyLevel}</p>
                  </div>
                </div>
                {analysis.visualFeedback.formatMistakes.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-red-400 mb-2">Format Mistakes:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      {analysis.visualFeedback.formatMistakes.map((mistake, i) => (
                        <li key={i}>{mistake}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              {/* Section 6: Improvement Guide */}
              <div className="p-6 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/30">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  6️⃣ Exact Improvement Guide
                </h2>
                <div className="space-y-4">
                  <div className="p-4 rounded-lg bg-card/50">
                    <p className="text-sm font-medium text-primary mb-2">Rewrite the Hook:</p>
                    <p className="text-sm text-muted-foreground">{analysis.improvementGuide.hookRewrite}</p>
                  </div>
                  <div className="p-4 rounded-lg bg-card/50">
                    <p className="text-sm font-medium text-green-400 mb-2">Pacing Tips:</p>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                      {analysis.improvementGuide.pacingTips.map((tip, i) => (
                        <li key={i}>{tip}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-card/50">
                      <p className="text-sm font-medium text-red-400 mb-2">What to Cut:</p>
                      <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                        {analysis.improvementGuide.whatToCut.map((item, i) => (
                          <li key={i}>{item}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="p-4 rounded-lg bg-card/50">
                      <p className="text-sm font-medium text-green-400 mb-2">What to Add:</p>
                      <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                        {analysis.improvementGuide.whatToAdd.map((item, i) => (
                          <li key={i}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  <div className="p-4 rounded-lg bg-card/50">
                    <p className="text-sm font-medium text-primary mb-2">Ideal Length for Next Video:</p>
                    <p className="text-sm text-muted-foreground">{analysis.improvementGuide.idealLength}</p>
                  </div>
                </div>
              </div>

              {/* Section 7: Next Video Recommendations */}
              <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-primary" />
                  7️⃣ Next Video Recommendations
                </h2>
                <div className="grid gap-4">
                  {analysis.nextVideoRecommendations.map((rec, index) => (
                    <div key={index} className="p-4 rounded-lg bg-secondary/30 relative">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute top-2 right-2"
                        onClick={() => copyToClipboard(`Title: ${rec.title}\nHook: ${rec.hookAngle}\nWhy: ${rec.whyItWillPerform}`, index)}
                      >
                        {copiedIndex === index ? (
                          <Check className="w-4 h-4 text-green-500" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                      <p className="font-semibold text-primary mb-2">{rec.title}</p>
                      <p className="text-sm text-muted-foreground mb-2">
                        <strong>Hook:</strong> {rec.hookAngle}
                      </p>
                      <p className="text-sm text-muted-foreground mb-2">
                        <strong>Why it will perform:</strong> {rec.whyItWillPerform}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong>Platform Advice:</strong> {rec.platformAdvice}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <UpgradePopup open={showUpgradePopup} onOpenChange={setShowUpgradePopup} />
    </div>
  );
}
