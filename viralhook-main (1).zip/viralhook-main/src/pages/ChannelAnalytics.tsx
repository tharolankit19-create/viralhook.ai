import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  ArrowLeft, 
  Search, 
  Loader2, 
  Users, 
  Eye, 
  Video, 
  TrendingUp,
  TrendingDown,
  Minus,
  Target,
  Lightbulb,
  AlertTriangle,
  UserCircle,
  Calendar,
  Copy,
  Check,
  Shield,
  BarChart3,
  Zap,
  Clock
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useCredits } from "@/contexts/CreditContext";
import { CREDIT_COSTS } from "@/lib/creditCosts";
import { toast } from "sonner";
import { ScrollArea } from "@/components/ui/scroll-area";

interface ContentSuggestion {
  title: string;
  hook: string;
  whyItFits: string;
  format: string;
  suggestedLength: string;
}

interface CompetitorAnalysis {
  suggestion: string;
  whatTheyDoBetter: string;
  whatToAdapt: string;
  whatToAvoid: string;
}

interface AnalysisResult {
  channelInfo: {
    name: string;
    thumbnail: string;
    subscriberCount: number;
    subscriberRange: string;
    totalViews: number;
    totalViewsFormatted: string;
    videoCount: number;
    uploadFrequency: string;
    contentType: string;
  };
  recentVideos: Array<{
    title: string;
    views: number;
    viewsFormatted: string;
    isShort: boolean;
  }>;
  analysis: {
    channelSnapshot: {
      realData: {
        subscriberRange: string;
        totalViews: string;
        totalVideos: number;
      };
      estimatedData: {
        viewsPerVideo: string;
        watchtimeTendency: string;
        growthMomentum: string;
      };
    };
    whatIsWorking: {
      topPerformingTopics: string[];
      titlePatterns: string[];
      thumbnailPatterns: string[];
      videoLengthTrends: string;
      whyTheyWork: string;
    };
    whatIsNotWorking: {
      lowPerformingTopics: string[];
      repetitiveFormats: string[];
      audienceFatigueSignals: string[];
      recommendations: string;
    };
    audienceProfile: {
      contentIntent: string;
      attentionSpan: string;
      audienceLevel: string;
      keyInterests: string[];
    };
    contentSuggestions: ContentSuggestion[];
    competitorAnalysis: CompetitorAnalysis[];
    thirtyDayPlan: {
      doubleDownOn: string[];
      stop: string[];
      experiment: string[];
      uploadFrequency: string;
    };
  };
}

export default function ChannelAnalytics() {
  const navigate = useNavigate();
  const { credits, deductCredits, isPremiumPlan, planType } = useCredits();
  const [channelUrl, setChannelUrl] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const handleAnalyze = async () => {
    if (!channelUrl.trim()) {
      toast.error("Please enter a YouTube channel URL");
      return;
    }
    if (!isPremiumPlan) {
      toast.error("This feature requires ₹499+ plan. Please upgrade.");
      return;
    }
    if (credits < CREDIT_COSTS.channelAnalysis) {
      toast.error(`Not enough credits. You need ${CREDIT_COSTS.channelAnalysis} credits.`);
      return;
    }
    setIsLoading(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("analyze-channel", {
        body: { channelUrl: channelUrl.trim() },
      });
      if (error) throw error;
      if (data.error) throw new Error(data.error);
      const success = await deductCredits(CREDIT_COSTS.channelAnalysis);
      if (!success) { toast.error("Failed to deduct credits"); return; }
      setResult(data);
      toast.success("Channel analysis complete!");
    } catch (error) {
      console.error("Analysis error:", error);
      toast.error(error instanceof Error ? error.message : "Failed to analyze channel");
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    toast.success("Copied!");
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const getMomentumIcon = (m: string) => {
    const l = m.toLowerCase();
    if (l.includes("growing")) return <TrendingUp className="w-4 h-4 text-green-500" />;
    if (l.includes("declining")) return <TrendingDown className="w-4 h-4 text-red-500" />;
    return <Minus className="w-4 h-4 text-yellow-500" />;
  };

  const getMomentumColor = (m: string) => {
    const l = m.toLowerCase();
    if (l.includes("growing")) return "text-green-600 bg-green-50 border-green-200";
    if (l.includes("declining")) return "text-red-600 bg-red-50 border-red-200";
    return "text-yellow-600 bg-yellow-50 border-yellow-200";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-primary/5">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}><ArrowLeft className="w-5 h-5" /></Button>
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">YouTube Channel Analysis</h1>
            <p className="text-muted-foreground text-sm">Real data + AI • {CREDIT_COSTS.channelAnalysis} credits/analysis</p>
          </div>
        </div>
        <Card className="mb-6 border-blue-200 bg-blue-50/50"><CardContent className="py-3 px-4"><div className="flex items-start gap-3"><Shield className="w-5 h-5 text-blue-600 mt-0.5 shrink-0" /><p className="text-sm text-blue-800">This analysis combines public YouTube data with AI pattern intelligence. Private analytics like exact watch time or CTR are not accessible.</p></div></CardContent></Card>
        <Card className="mb-6"><CardContent className="pt-6"><div className="flex flex-col sm:flex-row gap-3"><div className="flex-1"><Input placeholder="Enter YouTube channel URL or @handle" value={channelUrl} onChange={(e) => setChannelUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && handleAnalyze()} className="h-12" /></div><Button onClick={handleAnalyze} disabled={isLoading || !isPremiumPlan} className="h-12 px-8">{isLoading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Analyzing...</> : <><Search className="w-4 h-4 mr-2" />Analyze</>}</Button></div>{!isPremiumPlan && <p className="text-sm text-amber-600 mt-2">🔒 Requires ₹499+ plan. Current: {planType || "free"}</p>}</CardContent></Card>
        {isLoading && <Card><CardContent className="py-16 text-center"><Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-primary" /><h3 className="text-lg font-semibold mb-2">Analyzing...</h3><p className="text-muted-foreground text-sm">Fetching YouTube data and generating AI insights</p></CardContent></Card>}
        {result && (
          <div className="space-y-6">
            <Card><CardContent className="pt-6"><div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center"><img src={result.channelInfo.thumbnail} alt={result.channelInfo.name} className="w-20 h-20 rounded-full border-2 border-primary/20" /><div className="flex-1"><h2 className="text-2xl font-bold">{result.channelInfo.name}</h2><div className="flex flex-wrap gap-2 mt-2"><Badge variant="secondary"><Users className="w-3 h-3 mr-1" />{result.channelInfo.subscriberRange}</Badge><Badge variant="secondary"><Eye className="w-3 h-3 mr-1" />{result.channelInfo.totalViewsFormatted} views</Badge><Badge variant="secondary"><Video className="w-3 h-3 mr-1" />{result.channelInfo.videoCount} videos</Badge></div></div></div></CardContent></Card>
            <Card><CardHeader><CardTitle className="flex items-center gap-2"><BarChart3 className="w-5 h-5 text-primary" />1️⃣ Channel Snapshot</CardTitle></CardHeader><CardContent><div className="grid md:grid-cols-2 gap-6"><div><h4 className="font-semibold text-sm text-muted-foreground mb-3 uppercase">Real Data</h4><div className="space-y-2"><div className="flex justify-between py-2 border-b"><span>Subscribers</span><span className="font-semibold">{result.analysis.channelSnapshot.realData.subscriberRange}</span></div><div className="flex justify-between py-2 border-b"><span>Total Views</span><span className="font-semibold">{result.analysis.channelSnapshot.realData.totalViews}</span></div><div className="flex justify-between py-2 border-b"><span>Total Videos</span><span className="font-semibold">{result.analysis.channelSnapshot.realData.totalVideos}</span></div><div className="flex justify-between py-2"><span>Upload Frequency</span><span className="font-semibold">{result.channelInfo.uploadFrequency}</span></div></div></div><div><h4 className="font-semibold text-sm text-muted-foreground mb-3 uppercase">AI Estimated</h4><div className="space-y-3"><div className="p-3 rounded-lg bg-secondary/30 border"><p className="text-xs text-muted-foreground mb-1">Views/Video</p><p className="font-medium">{result.analysis.channelSnapshot.estimatedData.viewsPerVideo}</p></div><div className="p-3 rounded-lg bg-secondary/30 border"><p className="text-xs text-muted-foreground mb-1">Content Focus</p><p className="font-medium">{result.analysis.channelSnapshot.estimatedData.watchtimeTendency}</p></div><div className={`p-3 rounded-lg border ${getMomentumColor(result.analysis.channelSnapshot.estimatedData.growthMomentum)}`}><p className="text-xs opacity-70 mb-1">Growth</p><div className="flex items-center gap-2">{getMomentumIcon(result.analysis.channelSnapshot.estimatedData.growthMomentum)}<span className="font-medium">{result.analysis.channelSnapshot.estimatedData.growthMomentum}</span></div></div></div></div></div></CardContent></Card>
            <Card><CardHeader><CardTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5 text-green-500" />2️⃣ What's Working</CardTitle></CardHeader><CardContent className="space-y-4"><div className="grid md:grid-cols-2 gap-4"><div><h4 className="font-semibold mb-2">Top Topics</h4><ul className="space-y-1">{result.analysis.whatIsWorking.topPerformingTopics.map((t,i)=><li key={i} className="text-sm flex items-start gap-2"><span className="text-green-500 mt-1">✓</span>{t}</li>)}</ul></div><div><h4 className="font-semibold mb-2">Title Patterns</h4><ul className="space-y-1">{result.analysis.whatIsWorking.titlePatterns.map((t,i)=><li key={i} className="text-sm flex items-start gap-2"><span className="text-green-500 mt-1">✓</span>{t}</li>)}</ul></div></div><Separator /><div><h4 className="font-semibold mb-2">Video Length Trends</h4><p className="text-sm text-muted-foreground">{result.analysis.whatIsWorking.videoLengthTrends}</p></div><div className="p-4 bg-green-50 rounded-lg border border-green-200"><h4 className="font-semibold mb-2 text-green-800">Why These Work</h4><p className="text-sm text-green-700">{result.analysis.whatIsWorking.whyTheyWork}</p></div></CardContent></Card>
            <Card><CardHeader><CardTitle className="flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-amber-500" />3️⃣ What's Not Working</CardTitle></CardHeader><CardContent className="space-y-4"><div className="grid md:grid-cols-2 gap-4"><div><h4 className="font-semibold mb-2">Low Topics</h4><ul className="space-y-1">{result.analysis.whatIsNotWorking.lowPerformingTopics.map((t,i)=><li key={i} className="text-sm flex items-start gap-2"><span className="text-amber-500 mt-1">⚠</span>{t}</li>)}</ul></div><div><h4 className="font-semibold mb-2">Fatigue Signals</h4><ul className="space-y-1">{result.analysis.whatIsNotWorking.audienceFatigueSignals.map((s,i)=><li key={i} className="text-sm flex items-start gap-2"><span className="text-amber-500 mt-1">⚠</span>{s}</li>)}</ul></div></div><div className="p-4 bg-amber-50 rounded-lg border border-amber-200"><h4 className="font-semibold mb-2 text-amber-800">Recommendations</h4><p className="text-sm text-amber-700">{result.analysis.whatIsNotWorking.recommendations}</p></div></CardContent></Card>
            <Card><CardHeader><CardTitle className="flex items-center gap-2"><UserCircle className="w-5 h-5 text-blue-500" />4️⃣ Audience Profile</CardTitle></CardHeader><CardContent><div className="grid sm:grid-cols-3 gap-4 mb-4"><div className="p-4 bg-secondary/30 rounded-lg border text-center"><p className="text-xs text-muted-foreground mb-1">Intent</p><p className="font-semibold">{result.analysis.audienceProfile.contentIntent}</p></div><div className="p-4 bg-secondary/30 rounded-lg border text-center"><p className="text-xs text-muted-foreground mb-1">Attention</p><p className="font-semibold">{result.analysis.audienceProfile.attentionSpan}</p></div><div className="p-4 bg-secondary/30 rounded-lg border text-center"><p className="text-xs text-muted-foreground mb-1">Level</p><p className="font-semibold">{result.analysis.audienceProfile.audienceLevel}</p></div></div><div><h4 className="font-semibold mb-2">Interests</h4><div className="flex flex-wrap gap-2">{result.analysis.audienceProfile.keyInterests.map((i,idx)=><Badge key={idx} variant="outline">{i}</Badge>)}</div></div></CardContent></Card>
            <Card><CardHeader><CardTitle className="flex items-center gap-2"><Lightbulb className="w-5 h-5 text-yellow-500" />5️⃣ Content Suggestions</CardTitle></CardHeader><CardContent><ScrollArea className="h-[500px] pr-4"><div className="space-y-4">{result.analysis.contentSuggestions.map((s,i)=><div key={i} className="p-4 border rounded-lg bg-card hover:shadow-md transition-shadow"><div className="flex items-start justify-between gap-2 mb-2"><h4 className="font-semibold text-lg">{s.title}</h4><Button variant="ghost" size="icon" className="shrink-0" onClick={()=>copyToClipboard(s.title,i)}>{copiedIndex===i?<Check className="w-4 h-4 text-green-500"/>:<Copy className="w-4 h-4"/>}</Button></div><div className="flex gap-2 mb-3"><Badge variant={s.format==="Short"?"default":"secondary"}>{s.format}</Badge><Badge variant="outline"><Clock className="w-3 h-3 mr-1"/>{s.suggestedLength}</Badge></div><div className="space-y-2 text-sm"><div className="p-2 bg-primary/5 rounded border-l-2 border-primary"><span className="font-medium">Hook:</span> "{s.hook}"</div><p className="text-muted-foreground"><span className="font-medium text-foreground">Why:</span> {s.whyItFits}</p></div></div>)}</div></ScrollArea></CardContent></Card>
            <Card><CardHeader><CardTitle className="flex items-center gap-2"><Target className="w-5 h-5 text-purple-500" />6️⃣ Competitor Analysis</CardTitle></CardHeader><CardContent><div className="space-y-4">{result.analysis.competitorAnalysis.map((c,i)=><div key={i} className="p-4 border rounded-lg"><h4 className="font-semibold mb-3">{c.suggestion}</h4><div className="grid sm:grid-cols-3 gap-3 text-sm"><div className="p-2 bg-green-50 rounded border border-green-200"><p className="text-xs text-green-600 font-medium mb-1">Better</p><p className="text-green-800">{c.whatTheyDoBetter}</p></div><div className="p-2 bg-blue-50 rounded border border-blue-200"><p className="text-xs text-blue-600 font-medium mb-1">Adapt</p><p className="text-blue-800">{c.whatToAdapt}</p></div><div className="p-2 bg-red-50 rounded border border-red-200"><p className="text-xs text-red-600 font-medium mb-1">Avoid</p><p className="text-red-800">{c.whatToAvoid}</p></div></div></div>)}</div></CardContent></Card>
            <Card><CardHeader><CardTitle className="flex items-center gap-2"><Calendar className="w-5 h-5 text-indigo-500" />7️⃣ 30-Day Action Plan</CardTitle></CardHeader><CardContent><div className="grid md:grid-cols-2 gap-4"><div className="p-4 bg-green-50 rounded-lg border border-green-200"><h4 className="font-semibold text-green-800 mb-2 flex items-center gap-2"><Zap className="w-4 h-4"/>Double Down</h4><ul className="space-y-1">{result.analysis.thirtyDayPlan.doubleDownOn.map((i,idx)=><li key={idx} className="text-sm text-green-700 flex items-start gap-2"><span className="mt-1">→</span>{i}</li>)}</ul></div><div className="p-4 bg-red-50 rounded-lg border border-red-200"><h4 className="font-semibold text-red-800 mb-2">Stop</h4><ul className="space-y-1">{result.analysis.thirtyDayPlan.stop.map((i,idx)=><li key={idx} className="text-sm text-red-700 flex items-start gap-2"><span className="mt-1">✕</span>{i}</li>)}</ul></div><div className="p-4 bg-purple-50 rounded-lg border border-purple-200"><h4 className="font-semibold text-purple-800 mb-2">Experiment</h4><ul className="space-y-1">{result.analysis.thirtyDayPlan.experiment.map((i,idx)=><li key={idx} className="text-sm text-purple-700 flex items-start gap-2"><span className="mt-1">🧪</span>{i}</li>)}</ul></div><div className="p-4 bg-blue-50 rounded-lg border border-blue-200"><h4 className="font-semibold text-blue-800 mb-2">Upload Frequency</h4><p className="text-sm text-blue-700">{result.analysis.thirtyDayPlan.uploadFrequency}</p></div></div></CardContent></Card>
          </div>
        )}
      </div>
    </div>
  );
}
