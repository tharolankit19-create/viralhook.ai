import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useCredits } from "@/contexts/CreditContext";

const REDIRECT_KEY = "auth_redirect_to";

const plans = [
  {
    name: "Starter",
    price: "₹49",
    period: "",
    description: "Get started",
    credits: "5,000",
    creditsNum: 5000,
    features: [
      "5,000 credits",
      "Full AI access",
      "HD Thumbnails",
    ],
    cta: "Buy Now",
    popular: false,
  },
  {
    name: "Basic",
    price: "₹99",
    period: "",
    description: "For growing creators",
    credits: "13,000",
    creditsNum: 13000,
    features: [
      "13,000 credits",
      "Full AI access",
      "HD Thumbnails",
    ],
    cta: "Buy Now",
    popular: true,
  },
  {
    name: "Pro",
    price: "₹199",
    period: "",
    description: "For power users",
    credits: "25,000",
    creditsNum: 25000,
    features: [
      "25,000 credits",
      "Unlimited thumbnails",
      "Fast processing",
    ],
    cta: "Buy Now",
    popular: false,
  },
  {
    name: "Ultimate",
    price: "₹349",
    period: "",
    description: "Best value",
    credits: "40,000",
    creditsNum: 40000,
    features: [
      "40,000 credits",
      "Unlimited thumbnails",
      "Priority support",
    ],
    cta: "Buy Now",
    popular: false,
  },
];

export function PricingSection() {
  const navigate = useNavigate();
  const { user } = useCredits();

  const handlePlanClick = (planName: string) => {
    const destination = `/buy-credits?plan=${planName.toLowerCase()}`;
    
    if (user) {
      // User is logged in, go directly to buy credits
      navigate(destination);
    } else {
      // Store destination and redirect to login (not signup)
      sessionStorage.setItem(REDIRECT_KEY, destination);
      navigate("/auth");
    }
  };

  return (
    <section id="pricing" className="py-20 md:py-32 relative">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Simple, Transparent Pricing
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Pay only for what you use. No hidden fees, no commitments.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative p-6 rounded-2xl border backdrop-blur-sm transition-all duration-300 hover:scale-[1.02] ${
                plan.popular
                  ? "bg-primary/5 border-primary/50 shadow-[0_0_40px_hsl(var(--primary)/0.15)]"
                  : "bg-card/50 border-border/50 hover:border-primary/30"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary text-primary-foreground text-xs font-semibold rounded-full">
                  Most Popular
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>
              </div>

              <div className="mb-6 p-3 rounded-lg bg-secondary/50 text-center">
                <span className="text-2xl font-bold text-primary">{plan.credits}</span>
                <span className="text-muted-foreground text-sm"> credits</span>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 text-sm">
                    <Check className="w-4 h-4 text-primary flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={plan.popular ? "glow" : "outline"}
                className="w-full"
                onClick={() => handlePlanClick(plan.name)}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
