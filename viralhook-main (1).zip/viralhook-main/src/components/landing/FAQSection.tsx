import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How does the word-based credit system work?",
    answer:
      "Every time you generate captions and hooks, we count the words in the AI output. Those words are deducted from your monthly balance. For example, if you generate 10 hooks totaling 100 words, 100 words are deducted from your plan.",
  },
  {
    question: "Do unused words roll over to the next month?",
    answer:
      "Currently, words do not roll over. Your balance resets at the beginning of each billing cycle. We're considering rollover features for future plans.",
  },
  {
    question: "Which platforms are supported?",
    answer:
      "We support Instagram Reels, YouTube Shorts, TikTok, and X (Twitter). Each platform has optimized hook styles for maximum engagement.",
  },
  {
    question: "What languages can I generate content in?",
    answer:
      "We currently support English, Hindi, and Hinglish (a mix of Hindi and English). More languages coming soon!",
  },
  {
    question: "Can I cancel anytime?",
    answer:
      "Yes! You can cancel your subscription at any time. You'll continue to have access until the end of your billing period.",
  },
  {
    question: "What happens when I run out of words?",
    answer:
      "When your word balance reaches zero, you won't be able to generate new content until your balance resets or you upgrade your plan. We'll notify you when you're at 80% usage.",
  },
];

export function FAQSection() {
  return (
    <section id="faq" className="py-20 md:py-32 relative">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to know about ViralHook AI
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card/50 border border-border/50 rounded-xl px-6 data-[state=open]:border-primary/30"
              >
                <AccordionTrigger className="text-left hover:no-underline py-6">
                  <span className="font-semibold">{faq.question}</span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground pb-6">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
