import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const ANALYSIS_COST = 30;

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { videoUrl, platform, userId } = await req.json();

    if (!videoUrl || !platform || !userId) {
      return new Response(
        JSON.stringify({ error: "Video URL, platform, and user ID are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check user credits
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("credits, plan_type")
      .eq("id", userId)
      .single();

    if (profileError || !profile) {
      return new Response(
        JSON.stringify({ error: "User not found" }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Check access (₹199+ plans)
    const allowedPlans = ["creator", "pro", "elite"];
    if (!allowedPlans.includes(profile.plan_type || "")) {
      return new Response(
        JSON.stringify({ error: "This feature requires Creator (₹199) or higher plan" }),
        { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (profile.credits < ANALYSIS_COST) {
      return new Response(
        JSON.stringify({ error: `Insufficient credits. Need ${ANALYSIS_COST}, have ${profile.credits}` }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let videoData: any = {};
    const youtubeApiKey = Deno.env.get("YOUTUBE_API_KEY");

    // For YouTube, fetch real data
    if (platform === "youtube" && youtubeApiKey) {
      try {
        const videoId = extractYouTubeVideoId(videoUrl);
        if (videoId) {
          const ytResponse = await fetch(
            `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=${videoId}&key=${youtubeApiKey}`
          );
          const ytData = await ytResponse.json();
          
          if (ytData.items && ytData.items.length > 0) {
            const video = ytData.items[0];
            videoData = {
              title: video.snippet.title,
              description: video.snippet.description,
              channelTitle: video.snippet.channelTitle,
              publishedAt: video.snippet.publishedAt,
              duration: video.contentDetails.duration,
              viewCount: video.statistics.viewCount,
              likeCount: video.statistics.likeCount,
              commentCount: video.statistics.commentCount,
            };
          }
        }
      } catch (e) {
        console.error("YouTube API error:", e);
      }
    }

    // Call AI for analysis
    const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!lovableApiKey) {
      return new Response(
        JSON.stringify({ error: "AI service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const systemPrompt = `You are a senior video performance analyst for YouTube, Instagram, and Facebook.
Analyze the provided video data and return a comprehensive analysis.

IMPORTANT RULES:
- For YouTube: Use the real data provided
- For Instagram/Facebook: Use AI pattern analysis (no API access)
- NEVER claim access to private analytics (watch time, retention graphs)
- Be honest about what is estimated vs real data
- Provide actionable, practical advice
- Focus on what can be improved for the NEXT video

Return your analysis as a JSON object with this EXACT structure:
{
  "videoSnapshot": {
    "platform": "YouTube/Instagram/Facebook",
    "format": "Short/Long-form/Reel",
    "duration": "estimated or actual duration",
    "relativePerformance": "Low/Medium/High",
    "engagementQuality": "Weak/Average/Strong",
    "title": "video title if available",
    "viewCount": "view count if available",
    "uploadDate": "upload date if available"
  },
  "hookAnalysis": {
    "isHookClear": "Yes/No with explanation",
    "curiosityLevel": "Low/Medium/High with explanation",
    "scrollAwayReasons": ["reason 1", "reason 2"],
    "improvements": ["improvement 1", "improvement 2"]
  },
  "contentFlow": {
    "attentionDropPoints": ["where attention likely drops"],
    "pacingIssues": ["pacing issues identified"],
    "problemAreas": ["areas that need work"]
  },
  "titleCaptionReview": {
    "matchScore": "Good/Average/Poor - explanation",
    "clickMismatchIssues": ["issue 1", "issue 2"],
    "seoIssues": ["seo issue 1", "seo issue 2"]
  },
  "visualFeedback": {
    "lengthVsBestPractice": "assessment",
    "textReadability": "Good/Average/Poor",
    "energyLevel": "assessment",
    "formatMistakes": ["mistake 1", "mistake 2"]
  },
  "improvementGuide": {
    "hookRewrite": "suggested new hook for first 5 seconds",
    "pacingTips": ["tip 1", "tip 2"],
    "whatToCut": ["what to remove or shorten"],
    "whatToAdd": ["what to add or highlight"],
    "idealLength": "recommended length for next video"
  },
  "nextVideoRecommendations": [
    {
      "title": "suggested video title",
      "hookAngle": "hook for first 5 seconds",
      "whyItWillPerform": "explanation",
      "platformAdvice": "platform-specific advice"
    }
  ]
}`;

    const userPrompt = `Analyze this ${platform.toUpperCase()} video:

URL: ${videoUrl}
Platform: ${platform}

${Object.keys(videoData).length > 0 ? `
REAL DATA FROM API:
- Title: ${videoData.title || "N/A"}
- Channel: ${videoData.channelTitle || "N/A"}
- Description: ${videoData.description?.substring(0, 500) || "N/A"}
- Published: ${videoData.publishedAt || "N/A"}
- Duration: ${videoData.duration || "N/A"}
- Views: ${videoData.viewCount || "N/A"}
- Likes: ${videoData.likeCount || "N/A"}
- Comments: ${videoData.commentCount || "N/A"}
` : `
No API data available for ${platform}. Analyze based on URL pattern and platform best practices.
For Instagram/Facebook, provide pattern-based analysis.
`}

Provide a comprehensive analysis following the exact JSON structure specified.
Generate 2-3 next video recommendations that are specific to this content niche.`;

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${lovableApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.7,
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error("AI API error:", aiResponse.status, errorText);
      return new Response(
        JSON.stringify({ error: "AI analysis failed. Please try again." }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const aiData = await aiResponse.json();
    const content = aiData.choices?.[0]?.message?.content;

    if (!content) {
      return new Response(
        JSON.stringify({ error: "No analysis generated" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Parse JSON from response
    let analysis;
    try {
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysis = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error("No JSON found in response");
      }
    } catch (e) {
      console.error("JSON parse error:", e);
      return new Response(
        JSON.stringify({ error: "Failed to parse analysis" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Deduct credits after successful analysis
    const { error: deductError } = await supabase.rpc("deduct_credits", {
      user_id: userId,
      amount: ANALYSIS_COST,
    });

    if (deductError) {
      console.error("Credit deduction error:", deductError);
    }

    return new Response(
      JSON.stringify({ analysis, creditsUsed: ANALYSIS_COST }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: unknown) {
    console.error("Video analysis error:", error);
    const errorMessage = error instanceof Error ? error.message : "Analysis failed";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function extractYouTubeVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/)([^&\n?#]+)/,
    /youtube\.com\/shorts\/([^&\n?#]+)/,
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}
