import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Coins, Copy, CheckCircle2, Loader2, Shield, Sparkles, Lock, AlertTriangle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { AppHeader } from "@/components/AppHeader";
import { useCredits } from "@/contexts/CreditContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";

// Import QR codes for each plan
import upiQr49 from "@/assets/upi-qr-code.jpg";
import upiQr99 from "@/assets/upi-qr-99.jpg";
import upiQr199 from "@/assets/upi-qr-199.jpg";
import upiQr349 from "@/assets/upi-qr-349.jpg";

// New 4-tier pricing plans
const creditPacks = [
  { 
    credits: 490, 
    price: 49, 
    priceUSD: 1, 
    name: "Starter",
    description: "For beginners",
    features: [
      "Caption Generator - Unlimited",
      "Thumbnail Generator - Unlimited",
      "Other tools - 3 uses each",
    ],
    popular: false,
  },
  { 
    credits: 1990, 
    price: 199, 
    priceUSD: 3, 
    name: "Creator",
    description: "For growing creators",
    features: [
      "Caption Generator - Unlimited",
      "Thumbnail Generator - Unlimited",
      "Title/Hook Generator - Unlimited",
      "Video Analyze - Unlimited",
      "Channel Analytics - 3 uses",
    ],
    popular: true,
  },
  { 
    credits: 4990, 
    price: 499, 
    priceUSD: 6, 
    name: "Pro",
    description: "For professionals",
    features: [
      "ALL Tools - Unlimited",
      "Priority AI processing",
      "Full access to all features",
    ],
    popular: false,
  },
  { 
    credits: 9990, 
    price: 999, 
    priceUSD: 12, 
    name: "Elite",
    description: "For power users",
    features: [
      "Everything in Pro",
      "Fastest AI processing",
      "Best AI quality",
      "Early access to new features",
    ],
    popular: false,
  },
];

// QR code mapping by price
const qrCodeMap: Record<number, string> = {
  49: upiQr49,
  199: upiQr199,
  499: upiQr99,
  999: upiQr349,
};

// LAYER 1: Strict format validation - UPI-like patterns
const transactionSchema = z.object({
  orderId: z
    .string()
    .min(10, "Transaction ID must be at least 10 characters")
    .max(22, "Transaction ID must be at most 22 characters")
    .regex(/^[a-zA-Z0-9]{10,22}$/, "Transaction ID must be 10-22 alphanumeric characters only (no spaces or special characters)"),
});

const REDIRECT_KEY = "auth_redirect_to";
const PAYMENT_SESSION_DURATION = 15 * 60 * 1000; // 15 minutes in milliseconds

export default function BuyCredits() {
  const { user, refreshCredits } = useCredits();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const [selectedPack, setSelectedPack] = useState(creditPacks[1]); // Default to Creator
  const [orderId, setOrderId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [activationSuccess, setActivationSuccess] = useState(false);
  const [newBalance, setNewBalance] = useState<number | null>(null);
  
  // LAYER 3: Payment session timer
  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<number>(PAYMENT_SESSION_DURATION);
  const [sessionExpired, setSessionExpired] = useState(false);
  
  // LAYER 4: Payment confirmation checkbox
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);

  const upiId = "ankittharol@fam";

  useEffect(() => {
    if (!user) {
      sessionStorage.setItem(REDIRECT_KEY, `/buy-credits${window.location.search}`);
      navigate("/auth");
    }
  }, [user, navigate]);

  useEffect(() => {
    const planParam = searchParams.get("plan");
    if (planParam) {
      const matchedPack = creditPacks.find(
        (pack) => pack.name.toLowerCase() === planParam.toLowerCase()
      );
      if (matchedPack) {
        setSelectedPack(matchedPack);
      }
    }
  }, [searchParams]);

  // Start payment session when plan is selected
  useEffect(() => {
    setSessionStartTime(Date.now());
    setSessionExpired(false);
    setTimeRemaining(PAYMENT_SESSION_DURATION);
    setPaymentConfirmed(false);
    setOrderId("");
  }, [selectedPack]);

  // LAYER 3: Timer countdown
  useEffect(() => {
    if (!sessionStartTime) return;

    const interval = setInterval(() => {
      const elapsed = Date.now() - sessionStartTime;
      const remaining = PAYMENT_SESSION_DURATION - elapsed;
      
      if (remaining <= 0) {
        setSessionExpired(true);
        setTimeRemaining(0);
        clearInterval(interval);
      } else {
        setTimeRemaining(remaining);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [sessionStartTime]);

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const handleCopyUPI = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    toast({ title: "UPI ID copied!" });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRescanQR = () => {
    setSessionStartTime(Date.now());
    setSessionExpired(false);
    setTimeRemaining(PAYMENT_SESSION_DURATION);
    setPaymentConfirmed(false);
    setOrderId("");
    toast({ title: "Session renewed", description: "You have 15 minutes to complete the payment." });
  };

  const handleSubmitPayment = async () => {
    // LAYER 3: Check if session expired
    if (sessionExpired) {
      toast({
        title: "Payment Session Expired",
        description: "Please scan QR again to start a new payment session.",
        variant: "destructive",
      });
      return;
    }

    // LAYER 1: Format validation
    const validation = transactionSchema.safeParse({ orderId: orderId.trim() });
    if (!validation.success) {
      toast({
        title: "Invalid Transaction ID Format",
        description: validation.error.errors[0].message,
        variant: "destructive",
      });
      return;
    }

    // LAYER 4: Confirmation check
    if (!paymentConfirmed) {
      toast({
        title: "Payment Confirmation Required",
        description: "Please confirm that you completed the payment from your bank app.",
        variant: "destructive",
      });
      return;
    }

    if (!user?.email || !user?.id) {
      toast({
        title: "Authentication required",
        description: "Please log in to submit payment",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      const { data, error } = await supabase.rpc("verify_and_activate_plan", {
        p_order_id: orderId.trim(),
        p_email: user.email,
        p_user_id: user.id,
        p_plan_name: `${selectedPack.name} - ${selectedPack.credits} Credits`,
        p_amount: selectedPack.price,
        p_credits: selectedPack.credits,
      });

      if (error) throw error;

      const result = data as { success: boolean; error?: string; credits_added?: number; new_balance?: number; code?: string; plan_type?: string };

      if (!result.success) {
        // LAYER 2: Duplicate check handled by database
        if (result.code === "DUPLICATE_TRANSACTION") {
          toast({
            title: "Transaction ID Already Used",
            description: "This Transaction ID has already been used. Please enter a different transaction ID from a new payment.",
            variant: "destructive",
          });
        } else {
          toast({
            title: "Activation Failed",
            description: result.error || "Please try again or contact support.",
            variant: "destructive",
          });
        }
        return;
      }

      setActivationSuccess(true);
      setNewBalance(result.new_balance || null);
      await refreshCredits();

      toast({
        title: "Plan Activated! 🎉",
        description: `${result.credits_added?.toLocaleString()} credits have been added. You're now on ${selectedPack.name} plan!`,
      });

      setTimeout(() => {
        navigate("/dashboard");
      }, 3000);

    } catch (error) {
      console.error("Payment submission error:", error);
      toast({
        title: "Submission failed",
        description: "Please try again or contact support.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) return null;

  if (activationSuccess) {
    return (
      <div className="min-h-screen bg-background">
        <AppHeader />
        <main className="container px-4 py-12 flex items-center justify-center">
          <div className="max-w-md w-full text-center p-8 rounded-2xl bg-card/50 border border-primary/30 shadow-[0_0_40px_hsl(var(--primary)/0.15)]">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center">
              <CheckCircle2 className="w-10 h-10 text-primary" />
            </div>
            <h1 className="text-3xl font-bold mb-2 text-primary">Payment Received!</h1>
            <p className="text-lg text-muted-foreground mb-2">
              Your {selectedPack.name} plan is now active.
            </p>
            <div className="p-4 rounded-lg bg-secondary/50 mb-6">
              <p className="text-sm text-muted-foreground">New Credit Balance</p>
              <p className="text-4xl font-bold text-primary">
                {newBalance?.toLocaleString() || selectedPack.credits.toLocaleString()}
              </p>
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              Redirecting to dashboard...
            </p>
            <Button variant="glow" className="w-full" onClick={() => navigate("/dashboard")}>
              Go to Dashboard Now
            </Button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
            <Coins className="w-4 h-4" />
            <span className="text-sm font-medium">Upgrade Your Plan</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Choose Your Plan
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Credits = Price × 10 • Credits never expire
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Plan Selection */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {creditPacks.map((pack) => (
              <button
                key={pack.credits}
                onClick={() => setSelectedPack(pack)}
                className={`relative p-5 rounded-xl border text-left transition-all ${
                  selectedPack.credits === pack.credits
                    ? "border-primary bg-primary/5 shadow-[0_0_30px_hsl(var(--primary)/0.2)]"
                    : "border-border/50 bg-card/50 hover:border-primary/30"
                }`}
              >
                {pack.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-medium">
                    Most Popular
                  </div>
                )}
                <p className="text-2xl font-bold text-primary mb-1">₹{pack.price}</p>
                <p className="text-lg font-semibold mb-1">{pack.name}</p>
                <p className="text-sm text-muted-foreground mb-3">{pack.description}</p>
                <p className="text-sm font-medium text-primary mb-3">
                  {pack.credits.toLocaleString()} credits
                </p>
                <ul className="space-y-1">
                  {pack.features.map((feature, idx) => (
                    <li key={idx} className="text-xs text-muted-foreground flex items-start gap-1">
                      {feature.includes("3 uses") ? (
                        <Lock className="w-3 h-3 mt-0.5 flex-shrink-0 text-yellow-500" />
                      ) : (
                        <CheckCircle2 className="w-3 h-3 mt-0.5 flex-shrink-0 text-primary" />
                      )}
                      {feature}
                    </li>
                  ))}
                </ul>
              </button>
            ))}
          </div>

          {/* Payment Section */}
          <div className="max-w-md mx-auto">
            <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
              <h2 className="text-lg font-semibold mb-4 text-center">
                Pay ₹{selectedPack.price} for {selectedPack.name}
              </h2>
              
              {/* LAYER 3: Session Timer */}
              <div className={`flex items-center justify-center gap-2 p-3 rounded-lg mb-4 ${
                sessionExpired 
                  ? "bg-destructive/10 border border-destructive/30" 
                  : timeRemaining < 5 * 60 * 1000 
                    ? "bg-amber-500/10 border border-amber-500/30"
                    : "bg-secondary/50"
              }`}>
                <Clock className={`w-4 h-4 ${sessionExpired ? "text-destructive" : timeRemaining < 5 * 60 * 1000 ? "text-amber-500" : "text-muted-foreground"}`} />
                {sessionExpired ? (
                  <span className="text-sm text-destructive font-medium">
                    Session expired. Please scan QR again.
                  </span>
                ) : (
                  <span className={`text-sm font-medium ${timeRemaining < 5 * 60 * 1000 ? "text-amber-500" : "text-muted-foreground"}`}>
                    Payment window: {formatTime(timeRemaining)} remaining
                  </span>
                )}
              </div>

              {sessionExpired ? (
                <Button variant="glow" className="w-full mb-4" onClick={handleRescanQR}>
                  <Shield className="w-4 h-4 mr-2" />
                  Scan QR Again
                </Button>
              ) : (
                <>
                  <div className="flex justify-center mb-4">
                    <img
                      key={selectedPack.price}
                      src={qrCodeMap[selectedPack.price] || upiQr49}
                      alt={`UPI QR Code for ₹${selectedPack.price}`}
                      className="w-48 h-48 rounded-lg object-cover"
                    />
                  </div>

                  <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50 mb-4">
                    <span className="flex-1 text-sm font-mono">{upiId}</span>
                    <Button variant="ghost" size="sm" onClick={handleCopyUPI}>
                      {copied ? (
                        <CheckCircle2 className="w-4 h-4 text-primary" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="orderId">Transaction ID / UTR Number</Label>
                      <Input
                        id="orderId"
                        placeholder="e.g., ABC123456789XYZ"
                        value={orderId}
                        onChange={(e) => setOrderId(e.target.value.replace(/[^a-zA-Z0-9]/g, ""))}
                        className="bg-secondary/50 mt-1 font-mono"
                        maxLength={22}
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        10-22 alphanumeric characters only
                      </p>
                    </div>

                    {/* LAYER 4: Payment Confirmation Checkbox */}
                    <div className="flex items-start gap-3 p-3 rounded-lg bg-secondary/30 border border-border/50">
                      <Checkbox
                        id="paymentConfirmed"
                        checked={paymentConfirmed}
                        onCheckedChange={(checked) => setPaymentConfirmed(checked === true)}
                        className="mt-0.5"
                      />
                      <div className="flex-1">
                        <Label htmlFor="paymentConfirmed" className="text-sm cursor-pointer">
                          I confirm that I have completed the payment of ₹{selectedPack.price} from my bank/UPI app
                        </Label>
                      </div>
                    </div>

                    {/* Validation Feedback */}
                    {orderId.length > 0 && orderId.length < 10 && (
                      <div className="flex items-center gap-2 text-amber-500 text-sm">
                        <AlertTriangle className="w-4 h-4" />
                        Transaction ID must be at least 10 characters
                      </div>
                    )}

                    <Button
                      variant="glow"
                      className="w-full"
                      onClick={handleSubmitPayment}
                      disabled={submitting || !orderId.trim() || orderId.length < 10 || !paymentConfirmed || sessionExpired}
                    >
                      {submitting ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Verifying...
                        </>
                      ) : (
                        <>
                          <Shield className="w-4 h-4 mr-2" />
                          Verify & Activate {selectedPack.name}
                        </>
                      )}
                    </Button>
                    
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/5 border border-primary/20">
                      <Sparkles className="w-4 h-4 text-primary flex-shrink-0" />
                      <p className="text-xs text-muted-foreground">
                        <strong className="text-foreground">Instant activation!</strong> Credits added immediately after verification.
                      </p>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
