import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, X, Crown, Coins, Image, BarChart3, Settings, LogOut, Zap, Type, Lock, Users, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useCredits } from "@/contexts/CreditContext";
import { supabase } from "@/integrations/supabase/client";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface MenuItem {
  label: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  premium?: boolean;
  premiumMinPlan?: string;
  subtitle?: string;
}

const menuItems: MenuItem[] = [
  { label: "Thumbnail & Title Boost", href: "/title-boost", icon: Type },
  { label: "AI Thumbnail Generator", href: "/thumbnail-generator", icon: Image },
  { 
    label: "Video Analyze & Improve", 
    href: "/video-analyze", 
    icon: Video,
    premium: true,
    premiumMinPlan: "creator",
    subtitle: "Premium Feature (₹199+)"
  },
  { 
    label: "YouTube Audience Intelligence", 
    href: "/channel-analytics", 
    icon: Users,
    premium: true,
    premiumMinPlan: "pro",
    subtitle: "Premium Feature (₹499+)"
  },
  { label: "My Usage", href: "/usage", icon: BarChart3 },
  { label: "Buy Credits", href: "/buy-credits", icon: Coins },
  { label: "Account Settings", href: "/profile", icon: Settings },
];

export function HamburgerMenu() {
  const [open, setOpen] = useState(false);
  const [showUpgradeAlert, setShowUpgradeAlert] = useState(false);
  const { credits, user, planType, isPremiumPlan } = useCredits();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setOpen(false);
    navigate("/");
  };

  const handleUpgrade = () => {
    setOpen(false);
    navigate("/buy-credits");
  };

  const handleMenuClick = (item: MenuItem, e: React.MouseEvent) => {
    if (item.premium) {
      const minPlan = item.premiumMinPlan || "pro";
      const hasAccess = minPlan === "creator" 
        ? ["creator", "pro", "elite"].includes(planType || "")
        : isPremiumPlan;
      
      if (!hasAccess) {
        e.preventDefault();
        setShowUpgradeAlert(true);
        return;
      }
    }
    setOpen(false);
  };

  const getPlanDisplayName = () => {
    switch (planType) {
      case "starter": return "Starter Plan";
      case "creator": return "Creator Plan";
      case "pro": return "Pro Plan";
      case "elite": return "Elite Plan";
      default: return "Free Plan";
    }
  };

  if (!user) return null;

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="relative">
            <Menu className="h-6 w-6" />
            <span className="sr-only">Open menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="w-80 bg-card border-border p-0">
          <div className="flex flex-col h-full">
            {/* Header with Plan Badge */}
            <div className="p-6 border-b border-border bg-gradient-to-br from-primary/10 to-transparent">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/80 border border-primary/30">
                  <Zap className="w-4 h-4 text-primary" />
                  <span className="text-xs font-semibold">{getPlanDisplayName()}</span>
                </div>
                <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
                  <X className="h-5 w-5" />
                </Button>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <Coins className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{credits}</p>
                  <p className="text-sm text-muted-foreground">Credits remaining</p>
                </div>
              </div>
            </div>

            {/* Upgrade Button - Prominent */}
            <div className="p-4 border-b border-border">
              <Button
                variant="glow"
                className="w-full"
                onClick={handleUpgrade}
              >
                <Crown className="w-4 h-4 mr-2" />
                Upgrade Plan
              </Button>
              {credits <= 0 && (
                <p className="text-xs text-destructive text-center mt-2">
                  You've run out of credits!
                </p>
              )}
            </div>

            <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
              {menuItems.map((item) => {
                const minPlan = item.premiumMinPlan || "pro";
                const hasAccess = !item.premium || (minPlan === "creator" 
                  ? ["creator", "pro", "elite"].includes(planType || "")
                  : isPremiumPlan);
                const isLocked = item.premium && !hasAccess;
                
                return (
                  <Link
                    key={item.href}
                    to={isLocked ? "#" : item.href}
                    onClick={(e) => handleMenuClick(item, e)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors group ${
                      isLocked 
                        ? "opacity-75 cursor-not-allowed hover:bg-secondary/30" 
                        : "hover:bg-secondary/50"
                    }`}
                  >
                    <item.icon className={`h-5 w-5 transition-colors ${
                      isLocked 
                        ? "text-muted-foreground" 
                        : "text-muted-foreground group-hover:text-primary"
                    }`} />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`font-medium ${isLocked ? "text-muted-foreground" : ""}`}>
                          {item.label}
                        </span>
                        {isLocked && (
                          <Lock className="h-4 w-4 text-amber-500" />
                        )}
                      </div>
                      {item.subtitle && isLocked && (
                        <p className="text-xs text-amber-500/80 mt-0.5">{item.subtitle}</p>
                      )}
                    </div>
                  </Link>
                );
              })}
            </nav>

            {/* Footer */}
            <div className="p-4 border-t border-border">
              <p className="text-xs text-muted-foreground mb-3 truncate">
                {user.email}
              </p>
              <Button
                variant="outline"
                className="w-full"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      {/* Upgrade Alert Dialog */}
      <AlertDialog open={showUpgradeAlert} onOpenChange={setShowUpgradeAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-amber-500" />
              Premium Feature
            </AlertDialogTitle>
            <AlertDialogDescription>
              YouTube Audience Intelligence is available on the <strong>Pro (₹499)</strong> and <strong>Elite (₹999)</strong> plans. 
              Upgrade to unlock powerful channel analytics and audience insights.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              setShowUpgradeAlert(false);
              setOpen(false);
              navigate("/buy-credits");
            }}>
              <Crown className="h-4 w-4 mr-2" />
              Upgrade to ₹499 Plan
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
