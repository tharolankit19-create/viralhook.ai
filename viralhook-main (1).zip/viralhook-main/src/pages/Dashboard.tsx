import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Zap,
  Copy,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { UpgradePopup } from "@/components/UpgradePopup";
import { ReferralSection } from "@/components/ReferralSection";
import { useCredits } from "@/contexts/CreditContext";
import { CREDIT_COSTS } from "@/lib/creditCosts";

const platforms = [
  { value: "instagram", label: "Instagram Reels" },
  { value: "youtube", label: "YouTube Shorts" },
  { value: "tiktok", label: "TikTok" },
  { value: "twitter", label: "X (Twitter)" },
];

const languages = [
  { value: "english", label: "English" },
  { value: "hinglish", label: "Hinglish" },
  { value: "hindi", label: "Hindi" },
];

const styles = [
  { value: "viral", label: "Viral" },
  { value: "curiosity", label: "Curiosity" },
  { value: "emotional", label: "Emotional" },
  { value: "educational", label: "Educational" },
];

const CREDITS_PER_GENERATION = CREDIT_COSTS.caption;

const Dashboard = () => {
  const { user, credits, hasCredits, deductCredits, refreshCredits, showUpgradeModal, setShowUpgradeModal } = useCredits();
  const [topic, setTopic] = useState("");
  const [platform, setPlatform] = useState("instagram");
  const [language, setLanguage] = useState("english");
  const [style, setStyle] = useState("viral");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      navigate("/auth");
    }
  }, [user, navigate]);

  const handleGenerate = async () => {
    if (!topic.trim()) {
      toast({
        title: "Topic required",
        description: "Please enter a topic or idea to generate hooks.",
        variant: "destructive",
      });
      return;
    }

    if (credits < CREDITS_PER_GENERATION) {
      setShowUpgradeModal(true);
      return;
    }

    setLoading(true);
    setOutput("");

    try {
      // Deduct credits first
      const success = await deductCredits(CREDITS_PER_GENERATION);
      if (!success) {
        setShowUpgradeModal(true);
        return;
      }

      const response = await supabase.functions.invoke("generate-hooks", {
        body: {
          topic,
          platform,
          language,
          style,
        },
      });

      if (response.error) {
        throw new Error(response.error.message || "Generation failed");
      }

      const generatedText = response.data?.content || "";
      setOutput(generatedText);

      toast({
        title: "Generated!",
        description: `${CREDITS_PER_GENERATION} credits used.`,
      });

      await refreshCredits();
    } catch (error) {
      console.error("Generation error:", error);
      toast({
        title: "Generation failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    toast({
      title: "Copied!",
      description: "Content copied to clipboard.",
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Credit counter */}
          <div className="mb-8 p-4 rounded-xl bg-card/50 border border-border/50">
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className="text-sm font-medium">Credits remaining</span>
                <p className="text-xs text-muted-foreground">
                  You have 50 free credits to get started
                </p>
              </div>
              <span className="text-2xl font-bold text-primary">
                {credits}
              </span>
            </div>
            <div className="h-2 bg-secondary rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 ${
                  credits <= 50 ? "bg-destructive" : "bg-primary"
                }`}
                style={{ width: `${Math.min((credits / 500) * 100, 100)}%` }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {CREDITS_PER_GENERATION} credits per caption generation
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input section */}
            <div className="space-y-6">
              <div>
                <Label htmlFor="topic" className="text-base font-semibold mb-3 block">
                  What's your video about?
                </Label>
                <Textarea
                  id="topic"
                  placeholder="e.g., 5 morning habits that changed my life, How to grow on Instagram in 2024, Budget travel tips for students..."
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="min-h-[120px] bg-secondary/50 border-border/50 resize-none"
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label className="text-sm mb-2 block">Platform</Label>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger className="bg-secondary/50 border-border/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {platforms.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm mb-2 block">Language</Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className="bg-secondary/50 border-border/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((l) => (
                        <SelectItem key={l.value} value={l.value}>
                          {l.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm mb-2 block">Style</Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger className="bg-secondary/50 border-border/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {styles.map((s) => (
                        <SelectItem key={s.value} value={s.value}>
                          {s.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                variant="glow"
                className="w-full"
                onClick={handleGenerate}
                disabled={loading || !hasCredits}
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : !hasCredits ? (
                  <>
                    <AlertCircle className="w-4 h-4" />
                    No credits remaining
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4" />
                    Generate Captions & Hooks
                  </>
                )}
              </Button>
            </div>

            {/* Output section */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-base font-semibold">Generated Content</Label>
                {output && (
                  <Button variant="ghost" size="sm" onClick={handleCopy}>
                    {copied ? (
                      <CheckCircle2 className="w-4 h-4 text-primary" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                )}
              </div>
              <div className="min-h-[300px] p-4 rounded-xl bg-card/50 border border-border/50">
                {output ? (
                  <pre className="whitespace-pre-wrap text-sm font-sans leading-relaxed">
                    {output}
                  </pre>
                ) : (
                  <div className="h-full flex items-center justify-center text-muted-foreground text-sm">
                    Your generated hooks and captions will appear here
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Referral Section */}
          <div className="mt-8">
            <ReferralSection />
          </div>
        </div>
      </main>

      <UpgradePopup open={showUpgradeModal} onOpenChange={setShowUpgradeModal} />
    </div>
  );
};

export default Dashboard;
