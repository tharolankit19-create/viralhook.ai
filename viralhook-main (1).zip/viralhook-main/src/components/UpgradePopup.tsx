import { useNavigate } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Coins, Crown, Zap, AlertTriangle } from "lucide-react";
import { useCredits } from "@/contexts/CreditContext";

interface UpgradePopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const REDIRECT_KEY = "auth_redirect_to";

export function UpgradePopup({ open, onOpenChange }: UpgradePopupProps) {
  const navigate = useNavigate();
  const { user } = useCredits();

  const handleUpgrade = () => {
    onOpenChange(false);
    if (user) {
      navigate("/buy-credits");
    } else {
      sessionStorage.setItem(REDIRECT_KEY, "/buy-credits");
      navigate("/auth");
    }
  };

  const handleBuyCredits = () => {
    onOpenChange(false);
    if (user) {
      navigate("/buy-credits");
    } else {
      sessionStorage.setItem(REDIRECT_KEY, "/buy-credits");
      navigate("/auth");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader className="text-center">
          <div className="mx-auto w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-destructive" />
          </div>
          <DialogTitle className="text-2xl">You've Run Out of Credits!</DialogTitle>
          <DialogDescription className="text-base">
            Your 200 free credits have been exhausted. All AI tools are disabled until you upgrade or buy more credits.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 pt-4">
          <Button variant="glow" className="w-full" onClick={handleUpgrade}>
            <Crown className="w-4 h-4 mr-2" />
            Upgrade Plan
          </Button>
          <Button variant="outline" className="w-full" onClick={handleBuyCredits}>
            <Coins className="w-4 h-4 mr-2" />
            Buy Credits
          </Button>
        </div>

        <p className="text-xs text-muted-foreground text-center pt-2">
          <Zap className="w-3 h-3 inline mr-1" />
          Free plan includes 200 lifetime credits
        </p>
      </DialogContent>
    </Dialog>
  );
}
