import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles, Copy, Check, Zap, Type, Image, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AppHeader } from "@/components/AppHeader";
import { UpgradePopup } from "@/components/UpgradePopup";
import { useCredits } from "@/contexts/CreditContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { CREDIT_COSTS } from "@/lib/creditCosts";

const CREDITS_PER_GENERATION = CREDIT_COSTS.titleBoost;

const niches = [
  "Gaming",
  "Education",
  "Vlog",
  "Motivation",
  "Tech",
  "Finance",
  "Fitness",
  "Comedy",
  "Music",
  "News",
  "DIY",
  "Food",
  "Travel",
  "Beauty",
  "Other"
];

const platforms = [
  { value: "youtube", label: "YouTube" },
  { value: "youtube-shorts", label: "YouTube Shorts" }
];

const languages = [
  { value: "english", label: "English" },
  { value: "hinglish", label: "Hinglish" }
];

const styles = [
  { value: "safe", label: "Safe", description: "Clean & professional", locked: false },
  { value: "clickable", label: "Clickable", description: "Curiosity-driven", locked: false },
  { value: "viral", label: "Viral", description: "Maximum impact", locked: true }
];

interface GeneratedResult {
  titles: string[];
  thumbnailTexts: string[];
  emojis: string[];
  explanation: string;
}

export default function TitleBoost() {
  const { user, credits, hasCredits, deductCredits, showUpgradeModal, setShowUpgradeModal } = useCredits();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [topic, setTopic] = useState("");
  const [niche, setNiche] = useState("");
  const [platform, setPlatform] = useState("");
  const [language, setLanguage] = useState("");
  const [style, setStyle] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GeneratedResult | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<string | null>(null);
  
  // Check if user has access to viral mode (paid users have more credits)
  const isPaidUser = credits > 200;

  useEffect(() => {
    if (!user) {
      navigate("/auth");
    }
  }, [user, navigate]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(id);
    setTimeout(() => setCopiedIndex(null), 2000);
    toast({
      title: "Copied!",
      description: "Text copied to clipboard",
    });
  };

  const handleGenerate = async () => {
    if (!topic.trim() || !niche || !platform || !language || !style) {
      toast({
        title: "Missing fields",
        description: "Please fill in all fields to generate content.",
        variant: "destructive",
      });
      return;
    }

    if (credits < CREDITS_PER_GENERATION) {
      setShowUpgradeModal(true);
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      const { data, error } = await supabase.functions.invoke("generate-title-boost", {
        body: { topic, niche, platform, language, style },
      });

      if (error) throw new Error(error.message);
      if (data.error) throw new Error(data.error);

      const success = await deductCredits(CREDITS_PER_GENERATION);
      if (!success) {
        setShowUpgradeModal(true);
        return;
      }

      setResult(data);
      toast({
        title: "Generated!",
        description: `${CREDITS_PER_GENERATION} credit used.`,
      });
    } catch (error) {
      console.error("Generation error:", error);
      toast({
        title: "Generation failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
            <Zap className="w-4 h-4" />
            <span className="text-sm font-medium">Thumbnail & Title Boost</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Boost Your Click-Through Rate
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Generate high-CTR titles and thumbnail text that drive views
          </p>
          <p className="text-sm text-primary mt-2">
            {CREDITS_PER_GENERATION} credit per generation
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Form */}
            <Card className="bg-card/50 border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-primary" />
                  Generate Content
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="topic">Video Topic</Label>
                  <Input
                    id="topic"
                    placeholder="e.g., How I made $10k in one month"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    className="bg-secondary/50 border-border/50 mt-1"
                  />
                </div>

                <div>
                  <Label>Niche</Label>
                  <Select value={niche} onValueChange={setNiche}>
                    <SelectTrigger className="bg-secondary/50 border-border/50 mt-1">
                      <SelectValue placeholder="Select niche" />
                    </SelectTrigger>
                    <SelectContent>
                      {niches.map((n) => (
                        <SelectItem key={n} value={n.toLowerCase()}>{n}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Platform</Label>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger className="bg-secondary/50 border-border/50 mt-1">
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                    <SelectContent>
                      {platforms.map((p) => (
                        <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Language</Label>
                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className="bg-secondary/50 border-border/50 mt-1">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      {languages.map((l) => (
                        <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Style Mode</Label>
                  <div className="grid grid-cols-3 gap-2 mt-1">
                    {styles.map((s) => {
                      const isLocked = s.locked && !isPaidUser;
                      return (
                        <button
                          key={s.value}
                          onClick={() => !isLocked && setStyle(s.value)}
                          disabled={isLocked}
                          className={`relative p-3 rounded-lg border text-left transition-all ${
                            style === s.value
                              ? "border-primary bg-primary/10"
                              : isLocked
                              ? "border-border/30 bg-secondary/30 opacity-60 cursor-not-allowed"
                              : "border-border/50 bg-secondary/50 hover:border-primary/50"
                          }`}
                        >
                          {isLocked && (
                            <Lock className="absolute top-2 right-2 w-3 h-3 text-muted-foreground" />
                          )}
                          <p className="font-medium text-sm">{s.label}</p>
                          <p className="text-xs text-muted-foreground">{s.description}</p>
                        </button>
                      );
                    })}
                  </div>
                  {!isPaidUser && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Upgrade to unlock Viral mode
                    </p>
                  )}
                </div>

                <Button
                  variant="glow"
                  className="w-full mt-4"
                  onClick={handleGenerate}
                  disabled={loading || !hasCredits}
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                      Generating...
                    </>
                  ) : !hasCredits ? (
                    "No credits remaining"
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate Titles & Thumbnails
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Results */}
            <div className="space-y-4">
              {result ? (
                <>
                  {/* Titles */}
                  <Card className="bg-card/50 border-border/50">
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <Type className="w-5 h-5 text-primary" />
                        Video Titles
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {result.titles.map((title, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between gap-2 p-3 rounded-lg bg-secondary/50 border border-border/30 group"
                        >
                          <p className="text-sm flex-1">{title}</p>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleCopy(title, `title-${i}`)}
                          >
                            {copiedIndex === `title-${i}` ? (
                              <Check className="w-4 h-4 text-green-500" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Thumbnail Text */}
                  <Card className="bg-card/50 border-border/50">
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <Image className="w-5 h-5 text-primary" />
                        Thumbnail Text
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {result.thumbnailTexts.map((text, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between gap-2 p-3 rounded-lg bg-secondary/50 border border-border/30 group"
                        >
                          <p className="text-sm font-semibold flex-1">{text}</p>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleCopy(text, `thumb-${i}`)}
                          >
                            {copiedIndex === `thumb-${i}` ? (
                              <Check className="w-4 h-4 text-green-500" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Emojis & Explanation */}
                  <Card className="bg-card/50 border-border/50">
                    <CardContent className="pt-4 space-y-4">
                      {result.emojis && result.emojis.length > 0 && (
                        <div>
                          <p className="text-sm font-medium mb-2">Suggested Emojis</p>
                          <div className="flex gap-2">
                            {result.emojis.map((emoji, i) => (
                              <Badge key={i} variant="secondary" className="text-lg px-3 py-1">
                                {emoji}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      {result.explanation && (
                        <div>
                          <p className="text-sm font-medium mb-2">Why These Work</p>
                          <p className="text-sm text-muted-foreground">{result.explanation}</p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-full min-h-[300px] text-center p-8 rounded-xl border border-dashed border-border/50">
                  <Zap className="w-12 h-12 text-muted-foreground/30 mb-4" />
                  <p className="text-muted-foreground">
                    Fill in the form and click generate to see your high-CTR titles and thumbnail ideas
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <UpgradePopup open={showUpgradeModal} onOpenChange={setShowUpgradeModal} />
    </div>
  );
}
