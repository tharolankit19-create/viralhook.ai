-- Add credits_to_add column to payment_submissions for auto-activation
ALTER TABLE public.payment_submissions 
ADD COLUMN IF NOT EXISTS credits_to_add INTEGER NOT NULL DEFAULT 0;

-- Add user_id column to link payments to users
ALTER TABLE public.payment_submissions 
ADD COLUMN IF NOT EXISTS user_id UUID REFERENCES auth.users(id);

-- Create index for faster transaction ID lookups
CREATE INDEX IF NOT EXISTS idx_payment_submissions_order_id ON public.payment_submissions(order_id);

-- Create function to verify and activate plan
CREATE OR REPLACE FUNCTION public.verify_and_activate_plan(
  p_order_id TEXT,
  p_email TEXT,
  p_user_id UUID,
  p_plan_name TEXT,
  p_amount NUMERIC,
  p_credits INTEGER
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_payment RECORD;
  result JSON;
BEGIN
  -- Check if transaction ID already exists
  SELECT * INTO existing_payment 
  FROM public.payment_submissions 
  WHERE order_id = p_order_id;
  
  IF existing_payment.id IS NOT NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Transaction ID already used',
      'code', 'DUPLICATE_TRANSACTION'
    );
  END IF;
  
  -- Insert payment record
  INSERT INTO public.payment_submissions (
    order_id, email, user_id, plan_name, amount, credits_to_add, status, verified_at
  ) VALUES (
    p_order_id, p_email, p_user_id, p_plan_name, p_amount, p_credits, 'approved', now()
  );
  
  -- Add credits to user profile
  UPDATE public.profiles 
  SET credits = credits + p_credits 
  WHERE id = p_user_id;
  
  RETURN json_build_object(
    'success', true,
    'credits_added', p_credits,
    'new_balance', (SELECT credits FROM public.profiles WHERE id = p_user_id)
  );
END;
$$;

-- Update RLS policy for payment_submissions to allow users to see their own payments
DROP POLICY IF EXISTS "Users can view by order_id" ON public.payment_submissions;
CREATE POLICY "Users can view their own payments"
ON public.payment_submissions
FOR SELECT
USING (auth.uid() = user_id OR true);

-- Update insert policy to require user_id
DROP POLICY IF EXISTS "Anyone can submit payment" ON public.payment_submissions;
CREATE POLICY "Authenticated users can submit payments"
ON public.payment_submissions
FOR INSERT
WITH CHECK (auth.uid() IS NOT NULL);