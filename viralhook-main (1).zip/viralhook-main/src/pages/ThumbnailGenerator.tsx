import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Image, Sparkles, Download, RefreshCw, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AppHeader } from "@/components/AppHeader";
import { UpgradePopup } from "@/components/UpgradePopup";
import { useCredits } from "@/contexts/CreditContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { CREDIT_COSTS } from "@/lib/creditCosts";

const CREDITS_PER_GENERATION = CREDIT_COSTS.thumbnail;

const RATIOS = [
  { value: "16:9", label: "16:9 — YouTube Thumbnail", width: 1280, height: 720 },
  { value: "9:16", label: "9:16 — Shorts / Reels", width: 720, height: 1280 },
  { value: "1:1", label: "1:1 — Instagram Post", width: 1080, height: 1080 },
  { value: "4:5", label: "4:5 — Instagram Feed", width: 1080, height: 1350 },
];

const PLATFORMS = [
  { value: "youtube", label: "YouTube" },
  { value: "youtube-shorts", label: "YouTube Shorts" },
  { value: "instagram-reels", label: "Instagram Reels" },
  { value: "instagram-post", label: "Instagram Post" },
  { value: "facebook", label: "Facebook" },
];

const STYLES = [
  { value: "clean", label: "Clean" },
  { value: "bold", label: "Bold" },
  { value: "viral", label: "Viral" },
];

export default function ThumbnailGenerator() {
  const { user, credits, hasCredits, deductCredits, showUpgradeModal, setShowUpgradeModal } = useCredits();
  const navigate = useNavigate();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [prompt, setPrompt] = useState("");
  const [thumbnailText, setThumbnailText] = useState("");
  const [ratio, setRatio] = useState("16:9");
  const [platform, setPlatform] = useState("youtube");
  const [style, setStyle] = useState("bold");
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [description, setDescription] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate("/auth");
    }
  }, [user, navigate]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!validTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload JPG, PNG, or WEBP images only.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload an image smaller than 5MB.",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setUploadedImage(event.target?.result as string);
      setUploadedFileName(file.name);
    };
    reader.readAsDataURL(file);
  };

  const removeUploadedImage = () => {
    setUploadedImage(null);
    setUploadedFileName(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast({
        title: "Topic required",
        description: "Please describe your video topic.",
        variant: "destructive",
      });
      return;
    }

    if (credits < CREDITS_PER_GENERATION) {
      setShowUpgradeModal(true);
      return;
    }

    setLoading(true);
    try {
      const selectedRatio = RATIOS.find(r => r.value === ratio);
      
      const { data, error } = await supabase.functions.invoke("generate-thumbnail", {
        body: { 
          prompt,
          thumbnailText,
          ratio,
          platform,
          style,
          uploadedImage,
          width: selectedRatio?.width || 1280,
          height: selectedRatio?.height || 720,
        },
      });

      if (error) {
        throw new Error(error.message);
      }

      if (data.error) {
        throw new Error(data.error);
      }

      // Deduct credits after successful generation
      const success = await deductCredits(CREDITS_PER_GENERATION);
      if (!success) {
        setShowUpgradeModal(true);
        return;
      }

      setGeneratedImage(data.imageUrl);
      setDescription(data.description);

      toast({
        title: "Thumbnail generated!",
        description: `${CREDITS_PER_GENERATION} credits used.`,
      });
    } catch (error) {
      console.error("Generation error:", error);
      toast({
        title: "Generation failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = () => {
    if (!generatedImage) return;
    
    const link = document.createElement("a");
    link.href = generatedImage;
    link.download = `thumbnail-${platform}-${ratio.replace(":", "x")}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Download started",
      description: "Your thumbnail is being downloaded.",
    });
  };

  const getPreviewAspectClass = () => {
    switch (ratio) {
      case "9:16": return "aspect-[9/16] max-h-[500px]";
      case "1:1": return "aspect-square";
      case "4:5": return "aspect-[4/5]";
      default: return "aspect-video";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
            <Image className="w-4 h-4" />
            <span className="text-sm font-medium">AI Thumbnail Generator</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Create Stunning Thumbnails
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Generate professional, viral-ready thumbnails for any platform
          </p>
          <p className="text-sm text-primary mt-2">
            {CREDITS_PER_GENERATION} credits per generation
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Input Section */}
            <div className="space-y-5">
              {/* Topic */}
              <div>
                <Label htmlFor="prompt" className="text-base font-semibold mb-2 block">
                  Video Topic *
                </Label>
                <Textarea
                  id="prompt"
                  placeholder="e.g., 10 Morning Habits of Successful People, How to Edit Videos Like a Pro..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  className="min-h-[80px] bg-secondary/50 border-border/50"
                  disabled={!hasCredits}
                />
              </div>

              {/* Thumbnail Text */}
              <div>
                <Label htmlFor="thumbnailText" className="text-base font-semibold mb-2 block">
                  Thumbnail Text (Optional)
                </Label>
                <Input
                  id="thumbnailText"
                  placeholder="e.g., LIFE CHANGING, 10X Growth..."
                  value={thumbnailText}
                  onChange={(e) => setThumbnailText(e.target.value)}
                  className="bg-secondary/50 border-border/50"
                  disabled={!hasCredits}
                />
                <p className="text-xs text-muted-foreground mt-1">3-5 words max for best results</p>
              </div>

              {/* Ratio & Platform */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Ratio</Label>
                  <Select value={ratio} onValueChange={setRatio}>
                    <SelectTrigger className="bg-secondary/50 border-border/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border z-50">
                      {RATIOS.map((r) => (
                        <SelectItem key={r.value} value={r.value}>
                          {r.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Platform</Label>
                  <Select value={platform} onValueChange={setPlatform}>
                    <SelectTrigger className="bg-secondary/50 border-border/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border z-50">
                      {PLATFORMS.map((p) => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Style */}
              <div>
                <Label className="text-sm font-medium mb-2 block">Style</Label>
                <Select value={style} onValueChange={setStyle}>
                  <SelectTrigger className="bg-secondary/50 border-border/50">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border z-50">
                    {STYLES.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Photo Upload */}
              <div>
                <Label className="text-sm font-medium mb-2 block">
                  Upload Photo (Optional)
                </Label>
                <div className="border-2 border-dashed border-border/50 rounded-xl p-4 text-center bg-secondary/20">
                  {uploadedImage ? (
                    <div className="relative inline-block">
                      <img 
                        src={uploadedImage} 
                        alt="Uploaded" 
                        className="max-h-32 rounded-lg mx-auto"
                      />
                      <button
                        onClick={removeUploadedImage}
                        className="absolute -top-2 -right-2 w-6 h-6 bg-destructive text-destructive-foreground rounded-full flex items-center justify-center hover:bg-destructive/80"
                      >
                        <X className="w-4 h-4" />
                      </button>
                      <p className="text-xs text-muted-foreground mt-2">{uploadedFileName}</p>
                    </div>
                  ) : (
                    <>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/jpeg,image/png,image/webp"
                        onChange={handleFileUpload}
                        className="hidden"
                        id="photo-upload"
                      />
                      <label 
                        htmlFor="photo-upload" 
                        className="cursor-pointer flex flex-col items-center gap-2"
                      >
                        <Upload className="w-8 h-8 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">
                          Click to upload (JPG, PNG, WEBP)
                        </span>
                        <span className="text-xs text-muted-foreground">
                          Max 5MB • Your face will be preserved
                        </span>
                      </label>
                    </>
                  )}
                </div>
              </div>

              <Button
                variant="glow"
                className="w-full"
                onClick={handleGenerate}
                disabled={loading || !hasCredits}
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : !hasCredits ? (
                  "No credits remaining"
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    Generate Thumbnail ({CREDITS_PER_GENERATION} credits)
                  </>
                )}
              </Button>
            </div>

            {/* Output Section */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <Label className="text-base font-semibold">Generated Thumbnail</Label>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="px-2 py-1 rounded bg-secondary/50">{ratio}</span>
                  <span className="px-2 py-1 rounded bg-secondary/50">{PLATFORMS.find(p => p.value === platform)?.label}</span>
                </div>
              </div>
              <div className={`rounded-xl bg-card/50 border border-border/50 overflow-hidden flex items-center justify-center ${getPreviewAspectClass()}`}>
                {generatedImage ? (
                  <img
                    src={generatedImage}
                    alt="Generated thumbnail"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-muted-foreground text-sm text-center p-4">
                    Your generated thumbnail will appear here
                  </div>
                )}
              </div>
              {generatedImage && (
                <>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" className="flex-1" onClick={handleDownload}>
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                    <Button variant="outline" className="flex-1" onClick={handleGenerate} disabled={loading}>
                      <RefreshCw className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`} />
                      Regenerate
                    </Button>
                  </div>
                  {description && (
                    <div className="mt-4 p-4 rounded-lg bg-secondary/50 border border-border/50">
                      <p className="text-sm font-medium mb-2">AI Description:</p>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">{description}</p>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </main>

      <UpgradePopup open={showUpgradeModal} onOpenChange={setShowUpgradeModal} />
    </div>
  );
}
