import { Link } from "react-router-dom";
import { Zap } from "lucide-react";
import { HamburgerMenu } from "./HamburgerMenu";
import { useCredits } from "@/contexts/CreditContext";

export function AppHeader() {
  const { credits, user } = useCredits();

  return (
    <header className="border-b border-border/50 bg-background/80 backdrop-blur-xl sticky top-0 z-50">
      <div className="container px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Zap className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-bold text-lg">ViralHook AI</span>
          </Link>

          <div className="flex items-center gap-4">
            {user && (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/50">
                <Zap className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium">{credits} credits</span>
              </div>
            )}
            <HamburgerMenu />
          </div>
        </div>
      </div>
    </header>
  );
}
