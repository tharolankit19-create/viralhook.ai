// Credit costs per tool (per generation/action)
export const CREDIT_COSTS = {
  caption: 10,      // Caption/Hook Generator
  thumbnail: 20,    // Thumbnail Generator
  seo: 30,          // SEO Generator
  titleBoost: 10,   // Title/Hook Generator
  channelAnalysis: 50, // YouTube Audience Intelligence
  videoAnalysis: 30, // Video Analyze & Improvement Guide
} as const;

// Tool usage limits for different plans
export const TOOL_LIMITS = {
  free: {
    caption: -1, // Unlimited
    thumbnail: -1, // Unlimited
    titleBoost: 3, // Limited to 3
    seo: 3, // Limited to 3
    channelAnalysis: 3, // Limited to 3
  },
  starter: {
    caption: -1,
    thumbnail: -1,
    titleBoost: 3,
    seo: 3,
    channelAnalysis: 3,
  },
  creator: {
    caption: -1,
    thumbnail: -1,
    titleBoost: -1, // Unlimited
    seo: 3,
    channelAnalysis: 3,
  },
  pro: {
    caption: -1,
    thumbnail: -1,
    titleBoost: -1,
    seo: -1,
    channelAnalysis: -1, // All unlimited
  },
  elite: {
    caption: -1,
    thumbnail: -1,
    titleBoost: -1,
    seo: -1,
    channelAnalysis: -1, // All unlimited
  },
} as const;

export type ToolName = keyof typeof CREDIT_COSTS;
export type PlanType = keyof typeof TOOL_LIMITS;

export function getToolLimit(plan: PlanType, tool: ToolName): number {
  return TOOL_LIMITS[plan]?.[tool] ?? 3;
}

export function isToolUnlimited(plan: PlanType, tool: ToolName): boolean {
  return getToolLimit(plan, tool) === -1;
}
