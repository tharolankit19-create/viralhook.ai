import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface YouTubeVideo {
  id: string;
  title: string;
  publishedAt: string;
  viewCount?: string;
  likeCount?: string;
  commentCount?: string;
  duration?: string;
}

interface ChannelData {
  channelId: string;
  channelName: string;
  description: string;
  subscriberCount: string;
  viewCount: string;
  videoCount: string;
  thumbnailUrl: string;
  customUrl?: string;
}

async function extractChannelId(input: string, apiKey: string): Promise<string | null> {
  // Clean input
  input = input.trim();
  
  // Handle @username format
  if (input.includes("@")) {
    const handleMatch = input.match(/@([a-zA-Z0-9_-]+)/);
    if (handleMatch) {
      const handle = handleMatch[1];
      const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=@${handle}&key=${apiKey}`;
      const response = await fetch(searchUrl);
      const data = await response.json();
      if (data.items && data.items.length > 0) {
        return data.items[0].snippet.channelId;
      }
      // Try channels endpoint with forHandle
      const channelUrl = `https://www.googleapis.com/youtube/v3/channels?part=id&forHandle=${handle}&key=${apiKey}`;
      const channelResponse = await fetch(channelUrl);
      const channelData = await channelResponse.json();
      if (channelData.items && channelData.items.length > 0) {
        return channelData.items[0].id;
      }
    }
  }
  
  // Handle direct channel ID (starts with UC)
  if (input.match(/^UC[a-zA-Z0-9_-]{22}$/)) {
    return input;
  }
  
  // Extract from various URL formats
  const patterns = [
    /youtube\.com\/channel\/(UC[a-zA-Z0-9_-]{22})/,
    /youtube\.com\/c\/([^\/\?]+)/,
    /youtube\.com\/user\/([^\/\?]+)/,
    /youtube\.com\/@([^\/\?]+)/,
  ];
  
  for (const pattern of patterns) {
    const match = input.match(pattern);
    if (match) {
      if (match[1].startsWith("UC")) {
        return match[1];
      }
      // Search for the channel
      const searchUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=${encodeURIComponent(match[1])}&key=${apiKey}`;
      const response = await fetch(searchUrl);
      const data = await response.json();
      if (data.items && data.items.length > 0) {
        return data.items[0].snippet.channelId;
      }
    }
  }
  
  return null;
}

async function getChannelData(channelId: string, apiKey: string): Promise<ChannelData | null> {
  const url = `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=${channelId}&key=${apiKey}`;
  const response = await fetch(url);
  const data = await response.json();
  
  if (!data.items || data.items.length === 0) {
    return null;
  }
  
  const channel = data.items[0];
  return {
    channelId: channel.id,
    channelName: channel.snippet.title,
    description: channel.snippet.description || "",
    subscriberCount: channel.statistics.subscriberCount || "0",
    viewCount: channel.statistics.viewCount || "0",
    videoCount: channel.statistics.videoCount || "0",
    thumbnailUrl: channel.snippet.thumbnails?.high?.url || channel.snippet.thumbnails?.default?.url || "",
    customUrl: channel.snippet.customUrl || undefined,
  };
}

async function getRecentVideos(channelId: string, apiKey: string, maxResults: number = 20): Promise<YouTubeVideo[]> {
  // First get the uploads playlist ID
  const channelUrl = `https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=${channelId}&key=${apiKey}`;
  const channelResponse = await fetch(channelUrl);
  const channelData = await channelResponse.json();
  
  if (!channelData.items || channelData.items.length === 0) {
    return [];
  }
  
  const uploadsPlaylistId = channelData.items[0].contentDetails.relatedPlaylists.uploads;
  
  // Get recent videos from uploads playlist
  const playlistUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${uploadsPlaylistId}&maxResults=${maxResults}&key=${apiKey}`;
  const playlistResponse = await fetch(playlistUrl);
  const playlistData = await playlistResponse.json();
  
  if (!playlistData.items) {
    return [];
  }
  
  const videoIds = playlistData.items.map((item: any) => item.snippet.resourceId.videoId).join(",");
  
  // Get video statistics
  const videosUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails&id=${videoIds}&key=${apiKey}`;
  const videosResponse = await fetch(videosUrl);
  const videosData = await videosResponse.json();
  
  if (!videosData.items) {
    return [];
  }
  
  return videosData.items.map((video: any) => ({
    id: video.id,
    title: video.snippet.title,
    publishedAt: video.snippet.publishedAt,
    viewCount: video.statistics.viewCount || "0",
    likeCount: video.statistics.likeCount || "0",
    commentCount: video.statistics.commentCount || "0",
    duration: video.contentDetails.duration || "PT0S",
  }));
}

function parseDuration(duration: string): number {
  const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 0;
  const hours = parseInt(match[1] || "0");
  const minutes = parseInt(match[2] || "0");
  const seconds = parseInt(match[3] || "0");
  return hours * 3600 + minutes * 60 + seconds;
}

function formatSubscriberRange(count: number): string {
  if (count < 1000) return `~${count}`;
  if (count < 10000) return `~${Math.round(count / 1000)}K`;
  if (count < 100000) return `~${Math.floor(count / 10000) * 10}K–${Math.ceil(count / 10000) * 10}K`;
  if (count < 1000000) return `~${Math.floor(count / 100000) * 100}K–${Math.ceil(count / 100000) * 100}K`;
  return `~${(count / 1000000).toFixed(1)}M`;
}

function formatViewCount(count: number): string {
  if (count < 1000) return count.toString();
  if (count < 1000000) return `${(count / 1000).toFixed(1)}K`;
  if (count < 1000000000) return `${(count / 1000000).toFixed(1)}M`;
  return `${(count / 1000000000).toFixed(2)}B`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { channelUrl } = await req.json();

    if (!channelUrl) {
      return new Response(
        JSON.stringify({ error: "Channel URL is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const YOUTUBE_API_KEY = Deno.env.get("YOUTUBE_API_KEY");
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    
    if (!YOUTUBE_API_KEY) {
      throw new Error("YOUTUBE_API_KEY is not configured");
    }
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    console.log("Extracting channel ID from:", channelUrl);
    
    // Step 1: Extract channel ID
    const channelId = await extractChannelId(channelUrl, YOUTUBE_API_KEY);
    if (!channelId) {
      return new Response(
        JSON.stringify({ error: "Could not find YouTube channel. Please check the URL or handle." }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    console.log("Found channel ID:", channelId);
    
    // Step 2: Get channel data
    const channelData = await getChannelData(channelId, YOUTUBE_API_KEY);
    if (!channelData) {
      return new Response(
        JSON.stringify({ error: "Could not fetch channel data" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    console.log("Fetched channel:", channelData.channelName);
    
    // Step 3: Get recent videos
    const recentVideos = await getRecentVideos(channelId, YOUTUBE_API_KEY, 20);
    console.log(`Fetched ${recentVideos.length} recent videos`);
    
    // Step 4: Prepare data for AI analysis
    const subscriberCount = parseInt(channelData.subscriberCount);
    const totalViews = parseInt(channelData.viewCount);
    const videoCount = parseInt(channelData.videoCount);
    
    // Analyze video patterns
    const videoAnalysis = recentVideos.map(v => {
      const views = parseInt(v.viewCount || "0");
      const duration = parseDuration(v.duration || "PT0S");
      const isShort = duration <= 60;
      return {
        title: v.title,
        views,
        isShort,
        duration,
        publishedAt: v.publishedAt,
        engagement: parseInt(v.likeCount || "0") + parseInt(v.commentCount || "0"),
      };
    });
    
    const avgViews = videoAnalysis.reduce((sum, v) => sum + v.views, 0) / videoAnalysis.length || 0;
    const shortsCount = videoAnalysis.filter(v => v.isShort).length;
    const contentType = shortsCount > 15 ? "Shorts-focused" : shortsCount > 5 ? "Mixed" : "Long-form focused";
    
    // Calculate upload frequency
    const dates = videoAnalysis.map(v => new Date(v.publishedAt).getTime()).sort((a, b) => b - a);
    let avgDaysBetweenUploads = 7;
    if (dates.length > 1) {
      const daysDiff = (dates[0] - dates[dates.length - 1]) / (1000 * 60 * 60 * 24);
      avgDaysBetweenUploads = daysDiff / (dates.length - 1);
    }
    
    const uploadFrequency = avgDaysBetweenUploads < 1 ? "Multiple per day" :
                           avgDaysBetweenUploads < 2 ? "Daily" :
                           avgDaysBetweenUploads < 4 ? "2-3 times/week" :
                           avgDaysBetweenUploads < 8 ? "Weekly" : "Less than weekly";

    // Prepare AI prompt with real data
    const prompt = `You are an expert YouTube growth consultant. Analyze this channel based on REAL data and provide actionable insights.

CHANNEL DATA (REAL - FROM YOUTUBE API):
- Channel Name: ${channelData.channelName}
- Subscribers: ${formatSubscriberRange(subscriberCount)} (exact: ${subscriberCount})
- Total Views: ${formatViewCount(totalViews)}
- Total Videos: ${videoCount}
- Description: ${channelData.description.slice(0, 500)}
- Upload Frequency: ${uploadFrequency}
- Content Type: ${contentType}
- Average Views per Video (last 20): ${formatViewCount(avgViews)}

LAST 20 VIDEOS (with view counts):
${videoAnalysis.map((v, i) => `${i + 1}. "${v.title}" - ${formatViewCount(v.views)} views - ${v.isShort ? "Short" : `${Math.round(v.duration / 60)}min`}`).join("\n")}

Based on this REAL data, provide a comprehensive analysis in the following JSON structure:

{
  "channelSnapshot": {
    "realData": {
      "subscriberRange": "subscriber count range like ~10K-20K",
      "totalViews": "formatted total views",
      "totalVideos": ${videoCount}
    },
    "estimatedData": {
      "viewsPerVideo": "Low/Medium/High relative to subs with explanation",
      "watchtimeTendency": "Shorts-focused/Long-form focused/Mixed with reasoning",
      "growthMomentum": "Growing/Stable/Declining with evidence from data"
    }
  },
  "whatIsWorking": {
    "topPerformingTopics": ["topic1 with evidence", "topic2 with evidence"],
    "titlePatterns": ["pattern1 with examples", "pattern2 with examples"],
    "thumbnailPatterns": ["inferred pattern based on successful titles"],
    "videoLengthTrends": "what length performs best",
    "whyTheyWork": "detailed explanation connecting patterns to performance"
  },
  "whatIsNotWorking": {
    "lowPerformingTopics": ["topic with evidence"],
    "repetitiveFormats": ["format causing fatigue"],
    "audienceFatigueSignals": ["specific signals observed"],
    "recommendations": "what to reduce or stop"
  },
  "audienceProfile": {
    "contentIntent": "Entertainment/Education/Updates with reasoning",
    "attentionSpan": "Shorts-heavy/Long-watch/Mixed based on performance",
    "audienceLevel": "Beginner/Intermediate/Mixed with evidence",
    "keyInterests": ["interest1", "interest2", "interest3"]
  },
  "contentSuggestions": [
    {
      "title": "specific video title idea",
      "hook": "opening 5-second hook script",
      "whyItFits": "data-driven reasoning",
      "format": "Short/Long",
      "suggestedLength": "length range"
    }
  ],
  "competitorAnalysis": [
    {
      "suggestion": "channel niche/type to study",
      "whatTheyDoBetter": "specific strength",
      "whatToAdapt": "actionable adaptation",
      "whatToAvoid": "what not to copy"
    }
  ],
  "thirtyDayPlan": {
    "doubleDownOn": ["action1", "action2"],
    "stop": ["action1"],
    "experiment": ["experiment1", "experiment2"],
    "uploadFrequency": "recommended frequency with reasoning"
  }
}

CRITICAL RULES:
- Base ALL insights on the actual data provided
- Generate exactly 8-10 content suggestions that are specific to THIS channel
- Suggest 3-5 competitor analysis points (don't name specific channels, describe types)
- Never invent metrics that weren't provided
- Be specific and actionable, not generic
- Connect every recommendation to evidence from the data

Return ONLY valid JSON, no markdown.`;

    console.log("Calling Lovable AI for analysis...");

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content: "You are an expert YouTube growth analyst. Provide data-driven insights based only on the information given. Always respond with valid JSON only, no markdown formatting.",
          },
          { role: "user", content: prompt },
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI Gateway error:", response.status, errorText);
      
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again in a moment." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits depleted. Please contact support." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      throw new Error(`AI service error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error("No response from AI");
    }

    console.log("AI Response received, parsing...");

    // Parse the JSON response
    let analysisResult;
    try {
      const cleanContent = content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
      analysisResult = JSON.parse(cleanContent);
    } catch (parseError) {
      console.error("JSON parse error:", parseError, "Content:", content);
      throw new Error("Failed to parse analysis results");
    }

    // Combine real channel data with AI analysis
    const finalResult = {
      channelInfo: {
        name: channelData.channelName,
        thumbnail: channelData.thumbnailUrl,
        subscriberCount: subscriberCount,
        subscriberRange: formatSubscriberRange(subscriberCount),
        totalViews: totalViews,
        totalViewsFormatted: formatViewCount(totalViews),
        videoCount: videoCount,
        uploadFrequency: uploadFrequency,
        contentType: contentType,
      },
      recentVideos: videoAnalysis.slice(0, 10).map(v => ({
        title: v.title,
        views: v.views,
        viewsFormatted: formatViewCount(v.views),
        isShort: v.isShort,
      })),
      analysis: analysisResult,
    };

    console.log("Channel analysis complete for:", channelData.channelName);

    return new Response(JSON.stringify(finalResult), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in analyze-channel function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Analysis failed" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
