-- Update free credits from 200 to 50 for NEW users only
-- Existing users keep their current credits

-- Update the handle_new_user function to give 50 credits instead of 200
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  referrer_id UUID;
  ref_code TEXT;
BEGIN
  -- Get referral code from metadata if present
  ref_code := new.raw_user_meta_data ->> 'referral_code';
  
  -- Find referrer by code
  IF ref_code IS NOT NULL THEN
    SELECT id INTO referrer_id FROM public.profiles WHERE referral_code = ref_code;
  END IF;

  INSERT INTO public.profiles (id, email, full_name, avatar_url, credits, referred_by)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name'),
    new.raw_user_meta_data ->> 'avatar_url',
    50, -- Changed from 200 to 50 free credits
    referrer_id
  );
  RETURN new;
END;
$$;

-- Add tool usage tracking columns to profiles table for limited access features
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS tool_usage JSONB DEFAULT '{}'::jsonb,
ADD COLUMN IF NOT EXISTS plan_type TEXT DEFAULT 'free';

-- Create function to check and increment tool usage
CREATE OR REPLACE FUNCTION public.check_tool_usage(
  p_user_id UUID,
  p_tool_name TEXT,
  p_max_uses INTEGER
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  current_usage INTEGER;
  user_plan TEXT;
  result JSONB;
BEGIN
  -- Get current usage and plan
  SELECT 
    COALESCE((tool_usage->>p_tool_name)::INTEGER, 0),
    COALESCE(plan_type, 'free')
  INTO current_usage, user_plan
  FROM public.profiles 
  WHERE id = p_user_id;
  
  -- Pro and Elite plans have unlimited access
  IF user_plan IN ('pro', 'elite') THEN
    RETURN jsonb_build_object(
      'allowed', true,
      'current_usage', current_usage,
      'max_uses', -1,
      'unlimited', true
    );
  END IF;
  
  -- Check if user has reached limit
  IF current_usage >= p_max_uses THEN
    RETURN jsonb_build_object(
      'allowed', false,
      'current_usage', current_usage,
      'max_uses', p_max_uses,
      'unlimited', false
    );
  END IF;
  
  -- Increment usage
  UPDATE public.profiles 
  SET tool_usage = tool_usage || jsonb_build_object(p_tool_name, current_usage + 1)
  WHERE id = p_user_id;
  
  RETURN jsonb_build_object(
    'allowed', true,
    'current_usage', current_usage + 1,
    'max_uses', p_max_uses,
    'unlimited', false
  );
END;
$$;

-- Function to get tool usage stats
CREATE OR REPLACE FUNCTION public.get_tool_usage(p_user_id UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  result JSONB;
BEGIN
  SELECT 
    jsonb_build_object(
      'tool_usage', COALESCE(tool_usage, '{}'::jsonb),
      'plan_type', COALESCE(plan_type, 'free'),
      'is_paid_user', COALESCE(is_paid_user, false)
    )
  INTO result
  FROM public.profiles 
  WHERE id = p_user_id;
  
  RETURN COALESCE(result, jsonb_build_object('tool_usage', '{}'::jsonb, 'plan_type', 'free', 'is_paid_user', false));
END;
$$;

-- Update verify_and_activate_plan to set plan_type based on credits purchased
CREATE OR REPLACE FUNCTION public.verify_and_activate_plan(
  p_order_id TEXT, 
  p_email TEXT, 
  p_user_id UUID, 
  p_plan_name TEXT, 
  p_amount NUMERIC, 
  p_credits INTEGER
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  existing_payment RECORD;
  referrer_id UUID;
  bonus_credits INTEGER;
  existing_referral RECORD;
  referrer_is_paid BOOLEAN;
  new_plan_type TEXT;
  result JSON;
BEGIN
  -- Check if transaction ID already exists
  SELECT * INTO existing_payment 
  FROM public.payment_submissions 
  WHERE order_id = p_order_id;
  
  IF existing_payment.id IS NOT NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Transaction ID already used',
      'code', 'DUPLICATE_TRANSACTION'
    );
  END IF;
  
  -- Determine plan type based on amount
  CASE 
    WHEN p_amount = 49 THEN new_plan_type := 'starter';
    WHEN p_amount = 199 THEN new_plan_type := 'creator';
    WHEN p_amount = 499 THEN new_plan_type := 'pro';
    WHEN p_amount = 999 THEN new_plan_type := 'elite';
    ELSE new_plan_type := 'starter';
  END CASE;
  
  -- Insert payment record
  INSERT INTO public.payment_submissions (
    order_id, email, user_id, plan_name, amount, credits_to_add, status, verified_at
  ) VALUES (
    p_order_id, p_email, p_user_id, p_plan_name, p_amount, p_credits, 'approved', now()
  );
  
  -- Add credits to user profile, mark as paid user, set plan type, and reset tool usage on upgrade
  UPDATE public.profiles 
  SET 
    credits = credits + p_credits, 
    is_paid_user = true,
    plan_type = new_plan_type,
    tool_usage = '{}'::jsonb -- Reset usage limits on plan upgrade
  WHERE id = p_user_id;
  
  -- Handle referral bonus
  SELECT referred_by INTO referrer_id FROM public.profiles WHERE id = p_user_id;
  
  IF referrer_id IS NOT NULL THEN
    -- Check if referrer is a paid user
    SELECT is_paid_user INTO referrer_is_paid FROM public.profiles WHERE id = referrer_id;
    
    -- Check if this referral was already rewarded
    SELECT * INTO existing_referral 
    FROM public.referrals 
    WHERE referrer_user_id = referrer_id AND referred_user_id = p_user_id AND status = 'rewarded';
    
    -- Only reward if referrer is paid and not already rewarded
    IF referrer_is_paid = true AND existing_referral.id IS NULL THEN
      -- Calculate 25% bonus (rounded down)
      bonus_credits := FLOOR(p_credits * 0.25);
      
      -- Add bonus credits to referrer
      UPDATE public.profiles SET credits = credits + bonus_credits WHERE id = referrer_id;
      
      -- Record the referral
      INSERT INTO public.referrals (referrer_user_id, referred_user_id, purchased_credits, bonus_credits, status)
      VALUES (referrer_id, p_user_id, p_credits, bonus_credits, 'rewarded')
      ON CONFLICT (referrer_user_id, referred_user_id) 
      DO UPDATE SET 
        purchased_credits = public.referrals.purchased_credits + p_credits,
        bonus_credits = public.referrals.bonus_credits + bonus_credits,
        status = 'rewarded',
        updated_at = now();
    ELSIF referrer_is_paid = false AND existing_referral.id IS NULL THEN
      -- Record pending referral (referrer not eligible yet)
      INSERT INTO public.referrals (referrer_user_id, referred_user_id, purchased_credits, bonus_credits, status)
      VALUES (referrer_id, p_user_id, p_credits, 0, 'pending')
      ON CONFLICT (referrer_user_id, referred_user_id) DO NOTHING;
    END IF;
  END IF;
  
  RETURN json_build_object(
    'success', true,
    'credits_added', p_credits,
    'new_balance', (SELECT credits FROM public.profiles WHERE id = p_user_id),
    'plan_type', new_plan_type
  );
END;
$$;