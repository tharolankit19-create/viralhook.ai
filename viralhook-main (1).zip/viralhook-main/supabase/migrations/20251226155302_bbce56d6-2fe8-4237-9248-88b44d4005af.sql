-- Add referral columns to profiles table
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS referral_code TEXT UNIQUE,
ADD COLUMN IF NOT EXISTS referred_by UUID REFERENCES public.profiles(id),
ADD COLUMN IF NOT EXISTS is_paid_user BOOLEAN DEFAULT false;

-- Generate unique referral code for existing users
UPDATE public.profiles 
SET referral_code = UPPER(SUBSTRING(MD5(id::text || NOW()::text) FROM 1 FOR 8))
WHERE referral_code IS NULL;

-- Create referrals tracking table
CREATE TABLE public.referrals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  referred_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  purchased_credits INTEGER NOT NULL DEFAULT 0,
  bonus_credits INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'rewarded')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(referrer_user_id, referred_user_id)
);

-- Enable RLS on referrals
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;

-- Users can view their own referrals (as referrer)
CREATE POLICY "Users can view their referrals"
ON public.referrals
FOR SELECT
USING (auth.uid() = referrer_user_id);

-- System can insert referrals (via function)
CREATE POLICY "System can insert referrals"
ON public.referrals
FOR INSERT
WITH CHECK (true);

-- Create trigger for referrals updated_at
CREATE TRIGGER update_referrals_updated_at
BEFORE UPDATE ON public.referrals
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to generate referral code for new users
CREATE OR REPLACE FUNCTION public.generate_referral_code()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.referral_code IS NULL THEN
    NEW.referral_code := UPPER(SUBSTRING(MD5(NEW.id::text || NOW()::text) FROM 1 FOR 8));
  END IF;
  RETURN NEW;
END;
$$;

-- Create trigger to auto-generate referral code
CREATE TRIGGER generate_referral_code_on_insert
BEFORE INSERT ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.generate_referral_code();

-- Create function to get referral stats
CREATE OR REPLACE FUNCTION public.get_referral_stats(p_user_id UUID)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result JSON;
BEGIN
  SELECT json_build_object(
    'total_referrals', COALESCE(COUNT(*), 0),
    'total_credits_earned', COALESCE(SUM(bonus_credits), 0),
    'pending_referrals', COALESCE(COUNT(*) FILTER (WHERE status = 'pending'), 0),
    'rewarded_referrals', COALESCE(COUNT(*) FILTER (WHERE status = 'rewarded'), 0)
  ) INTO result
  FROM public.referrals
  WHERE referrer_user_id = p_user_id;
  
  RETURN result;
END;
$$;

-- Update handle_new_user to handle referral code from signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  referrer_id UUID;
  ref_code TEXT;
BEGIN
  -- Get referral code from metadata if present
  ref_code := new.raw_user_meta_data ->> 'referral_code';
  
  -- Find referrer by code
  IF ref_code IS NOT NULL THEN
    SELECT id INTO referrer_id FROM public.profiles WHERE referral_code = ref_code;
  END IF;

  INSERT INTO public.profiles (id, email, full_name, avatar_url, credits, referred_by)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data ->> 'full_name', new.raw_user_meta_data ->> 'name'),
    new.raw_user_meta_data ->> 'avatar_url',
    200,
    referrer_id
  );
  RETURN new;
END;
$$;

-- Update verify_and_activate_plan to handle referral bonuses
CREATE OR REPLACE FUNCTION public.verify_and_activate_plan(
  p_order_id TEXT, 
  p_email TEXT, 
  p_user_id UUID, 
  p_plan_name TEXT, 
  p_amount NUMERIC, 
  p_credits INTEGER
)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  existing_payment RECORD;
  referrer_id UUID;
  bonus_credits INTEGER;
  existing_referral RECORD;
  referrer_is_paid BOOLEAN;
  result JSON;
BEGIN
  -- Check if transaction ID already exists
  SELECT * INTO existing_payment 
  FROM public.payment_submissions 
  WHERE order_id = p_order_id;
  
  IF existing_payment.id IS NOT NULL THEN
    RETURN json_build_object(
      'success', false,
      'error', 'Transaction ID already used',
      'code', 'DUPLICATE_TRANSACTION'
    );
  END IF;
  
  -- Insert payment record
  INSERT INTO public.payment_submissions (
    order_id, email, user_id, plan_name, amount, credits_to_add, status, verified_at
  ) VALUES (
    p_order_id, p_email, p_user_id, p_plan_name, p_amount, p_credits, 'approved', now()
  );
  
  -- Add credits to user profile and mark as paid user
  UPDATE public.profiles 
  SET credits = credits + p_credits, is_paid_user = true 
  WHERE id = p_user_id;
  
  -- Handle referral bonus
  SELECT referred_by INTO referrer_id FROM public.profiles WHERE id = p_user_id;
  
  IF referrer_id IS NOT NULL THEN
    -- Check if referrer is a paid user
    SELECT is_paid_user INTO referrer_is_paid FROM public.profiles WHERE id = referrer_id;
    
    -- Check if this referral was already rewarded
    SELECT * INTO existing_referral 
    FROM public.referrals 
    WHERE referrer_user_id = referrer_id AND referred_user_id = p_user_id AND status = 'rewarded';
    
    -- Only reward if referrer is paid and not already rewarded
    IF referrer_is_paid = true AND existing_referral.id IS NULL THEN
      -- Calculate 25% bonus (rounded down)
      bonus_credits := FLOOR(p_credits * 0.25);
      
      -- Add bonus credits to referrer
      UPDATE public.profiles SET credits = credits + bonus_credits WHERE id = referrer_id;
      
      -- Record the referral
      INSERT INTO public.referrals (referrer_user_id, referred_user_id, purchased_credits, bonus_credits, status)
      VALUES (referrer_id, p_user_id, p_credits, bonus_credits, 'rewarded')
      ON CONFLICT (referrer_user_id, referred_user_id) 
      DO UPDATE SET 
        purchased_credits = public.referrals.purchased_credits + p_credits,
        bonus_credits = public.referrals.bonus_credits + bonus_credits,
        status = 'rewarded',
        updated_at = now();
    ELSIF referrer_is_paid = false AND existing_referral.id IS NULL THEN
      -- Record pending referral (referrer not eligible yet)
      INSERT INTO public.referrals (referrer_user_id, referred_user_id, purchased_credits, bonus_credits, status)
      VALUES (referrer_id, p_user_id, p_credits, 0, 'pending')
      ON CONFLICT (referrer_user_id, referred_user_id) DO NOTHING;
    END IF;
  END IF;
  
  RETURN json_build_object(
    'success', true,
    'credits_added', p_credits,
    'new_balance', (SELECT credits FROM public.profiles WHERE id = p_user_id)
  );
END;
$$;