import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { BarChart3, Zap, Calendar, TrendingUp } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { useCredits } from "@/contexts/CreditContext";
import { Progress } from "@/components/ui/progress";

export default function Usage() {
  const { user, credits } = useCredits();
  const navigate = useNavigate();

  const startingCredits = 200;
  const creditsUsed = startingCredits - credits;
  const usagePercentage = Math.min((creditsUsed / startingCredits) * 100, 100);

  useEffect(() => {
    if (!user) {
      navigate("/auth");
    }
  }, [user, navigate]);

  const stats = [
    {
      label: "Credits Remaining",
      value: credits,
      icon: Zap,
      color: "text-primary",
    },
    {
      label: "Credits Used",
      value: creditsUsed,
      icon: TrendingUp,
      color: "text-orange-400",
    },
    {
      label: "Starting Credits",
      value: startingCredits,
      icon: Calendar,
      color: "text-muted-foreground",
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
            <BarChart3 className="w-4 h-4" />
            <span className="text-sm font-medium">My Usage</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Credit Usage Overview
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Track your credit consumption and usage history
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            {stats.map((stat) => (
              <div
                key={stat.label}
                className="p-6 rounded-2xl bg-card/50 border border-border/50 text-center"
              >
                <stat.icon className={`w-8 h-8 mx-auto mb-3 ${stat.color}`} />
                <p className="text-3xl font-bold mb-1">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Usage Progress */}
          <div className="p-6 rounded-2xl bg-card/50 border border-border/50 mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Credit Usage</h2>
              <span className="text-sm text-muted-foreground">
                {usagePercentage.toFixed(1)}% used
              </span>
            </div>
            <Progress value={usagePercentage} className="h-3 mb-4" />
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>{creditsUsed} credits used</span>
              <span>{credits} credits remaining</span>
            </div>
          </div>

          {/* Usage Breakdown */}
          <div className="p-6 rounded-2xl bg-card/50 border border-border/50">
            <h2 className="text-lg font-semibold mb-4">Usage by Feature</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Zap className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Hook Generator</p>
                    <p className="text-sm text-muted-foreground">AI captions & hooks</p>
                  </div>
                </div>
                <span className="font-semibold">{Math.floor(creditsUsed * 0.6)} credits</span>
              </div>

              <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <BarChart3 className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">Thumbnail Generator</p>
                    <p className="text-sm text-muted-foreground">AI thumbnails</p>
                  </div>
                </div>
                <span className="font-semibold">{Math.floor(creditsUsed * 0.4)} credits</span>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
