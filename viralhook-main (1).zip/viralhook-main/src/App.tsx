import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { CreditProvider } from "@/contexts/CreditContext";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import AuthCallback from "./pages/AuthCallback";
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile";
import UpgradePlan from "./pages/UpgradePlan";
import BuyCredits from "./pages/BuyCredits";
import ThumbnailGenerator from "./pages/ThumbnailGenerator";
import TitleBoost from "./pages/TitleBoost";
import ChannelAnalytics from "./pages/ChannelAnalytics";
import VideoAnalyze from "./pages/VideoAnalyze";
import Usage from "./pages/Usage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <CreditProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/auth/callback" element={<AuthCallback />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/upgrade" element={<UpgradePlan />} />
            <Route path="/buy-credits" element={<BuyCredits />} />
            <Route path="/thumbnail-generator" element={<ThumbnailGenerator />} />
            <Route path="/title-boost" element={<TitleBoost />} />
            <Route path="/channel-analytics" element={<ChannelAnalytics />} />
            <Route path="/video-analyze" element={<VideoAnalyze />} />
            <Route path="/usage" element={<Usage />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </CreditProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
