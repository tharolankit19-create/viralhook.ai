import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Check, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AppHeader } from "@/components/AppHeader";
import { useCredits } from "@/contexts/CreditContext";

const plans = [
  {
    name: "Starter",
    price: "₹49",
    credits: 5000,
    features: ["5,000 credits", "Full AI access", "HD Thumbnails"],
    popular: false,
  },
  {
    name: "Basic",
    price: "₹129",
    credits: 13000,
    features: ["13,000 credits", "Full AI access", "HD Thumbnails"],
    popular: true,
  },
  {
    name: "Pro",
    price: "₹199",
    credits: 25000,
    features: ["25,000 credits", "Unlimited thumbnails", "Fast processing"],
    popular: false,
  },
  {
    name: "Ultimate",
    price: "₹349",
    credits: 40000,
    features: ["40,000 credits", "Unlimited thumbnails", "Priority support"],
    popular: false,
  },
];

export default function UpgradePlan() {
  const { user } = useCredits();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate("/auth");
    }
  }, [user, navigate]);

  const handleSelectPlan = (planName: string) => {
    navigate(`/buy-credits?plan=${planName.toLowerCase()}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader />

      <main className="container px-4 py-12">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-4">
            <Crown className="w-4 h-4" />
            <span className="text-sm font-medium">Upgrade Your Plan</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">
            Choose Your Plan
          </h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            Get more credits and unlock the full potential of AI tools
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative p-6 rounded-2xl border transition-all duration-300 hover:scale-[1.02] ${
                plan.popular
                  ? "bg-primary/5 border-primary/50 shadow-[0_0_40px_hsl(var(--primary)/0.15)]"
                  : "bg-card/50 border-border/50 hover:border-primary/30"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary text-primary-foreground text-xs font-semibold rounded-full">
                  Most Popular
                </div>
              )}

              <div className="mb-6">
                <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-bold">{plan.price}</span>
                </div>
              </div>

              <div className="mb-6 p-3 rounded-lg bg-secondary/50 text-center">
                <span className="text-2xl font-bold text-primary">
                  {plan.credits.toLocaleString()}
                </span>
                <span className="text-muted-foreground text-sm"> credits</span>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3 text-sm">
                    <Check className="w-4 h-4 text-primary flex-shrink-0" />
                    <span className="text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                variant={plan.popular ? "glow" : "outline"}
                className="w-full"
                onClick={() => handleSelectPlan(plan.name)}
              >
                Buy Now
              </Button>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
