-- Add gemini_api_key column to profiles table (encrypted at rest by Supabase)
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS gemini_api_key TEXT;

-- RLS policy: Users can only read/update their own API key
CREATE POLICY "Users can view their own gemini key" 
ON public.profiles 
FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Users can update their own gemini key" 
ON public.profiles 
FOR UPDATE 
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);