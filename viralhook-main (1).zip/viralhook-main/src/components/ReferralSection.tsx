import { useState, useEffect } from "react";
import { Copy, CheckCircle2, Users, Gift, Lock, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useCredits } from "@/contexts/CreditContext";

interface ReferralStats {
  total_referrals: number;
  total_credits_earned: number;
  pending_referrals: number;
  rewarded_referrals: number;
}

export function ReferralSection() {
  const { user } = useCredits();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [referralCode, setReferralCode] = useState<string | null>(null);
  const [isPaidUser, setIsPaidUser] = useState(false);
  const [stats, setStats] = useState<ReferralStats>({
    total_referrals: 0,
    total_credits_earned: 0,
    pending_referrals: 0,
    rewarded_referrals: 0,
  });

  useEffect(() => {
    if (!user?.id) return;

    const fetchReferralData = async () => {
      setLoading(true);
      try {
        // Fetch user profile for referral code and paid status
        const { data: profile, error: profileError } = await supabase
          .from("profiles")
          .select("referral_code, is_paid_user")
          .eq("id", user.id)
          .maybeSingle();

        if (profileError) throw profileError;

        if (profile) {
          setReferralCode(profile.referral_code);
          setIsPaidUser(profile.is_paid_user || false);
        }

        // Fetch referral stats
        const { data: statsData, error: statsError } = await supabase.rpc(
          "get_referral_stats",
          { p_user_id: user.id }
        );

        if (statsError) throw statsError;

        if (statsData) {
          setStats(statsData as unknown as ReferralStats);
        }
      } catch (error) {
        console.error("Error fetching referral data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchReferralData();
  }, [user?.id]);

  const referralLink = referralCode
    ? `${window.location.origin}/auth?ref=${referralCode}`
    : "";

  const handleCopyLink = () => {
    if (!referralLink) return;
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    toast({ title: "Referral link copied!" });
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="p-6 rounded-xl bg-card/50 border border-border/50">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  // Not eligible (free user)
  if (!isPaidUser) {
    return (
      <div className="p-6 rounded-xl bg-card/50 border border-border/50">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
            <Lock className="w-5 h-5 text-muted-foreground" />
          </div>
          <div>
            <h3 className="font-semibold">Refer & Earn Credits</h3>
            <p className="text-sm text-muted-foreground">Unlock referrals</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mb-4">
          Upgrade to a paid plan to unlock referrals and earn 25% bonus credits
          when your friends purchase any plan.
        </p>
        <Button
          variant="outline"
          className="w-full"
          onClick={() => (window.location.href = "/buy-credits")}
        >
          Upgrade to Unlock
        </Button>
      </div>
    );
  }

  // Eligible (paid user)
  return (
    <div className="p-6 rounded-xl bg-card/50 border border-primary/20 shadow-[0_0_20px_hsl(var(--primary)/0.08)]">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Gift className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-semibold">Refer & Earn Credits</h3>
          <p className="text-sm text-muted-foreground">
            Earn 25% bonus when friends buy
          </p>
        </div>
      </div>

      {/* Referral Link */}
      <div className="mb-4">
        <label className="text-xs text-muted-foreground mb-1 block">
          Your Referral Link
        </label>
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={referralLink}
            readOnly
            className="flex-1 px-3 py-2 rounded-lg bg-secondary/50 border border-border/50 text-sm font-mono truncate"
          />
          <Button variant="outline" size="sm" onClick={handleCopyLink}>
            {copied ? (
              <CheckCircle2 className="w-4 h-4 text-primary" />
            ) : (
              <Copy className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="p-3 rounded-lg bg-secondary/30">
          <div className="flex items-center gap-2 mb-1">
            <Users className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">
              Total Referrals
            </span>
          </div>
          <p className="text-xl font-bold">{stats.total_referrals}</p>
        </div>
        <div className="p-3 rounded-lg bg-secondary/30">
          <div className="flex items-center gap-2 mb-1">
            <Gift className="w-4 h-4 text-primary" />
            <span className="text-xs text-muted-foreground">
              Credits Earned
            </span>
          </div>
          <p className="text-xl font-bold text-primary">
            {stats.total_credits_earned}
          </p>
        </div>
      </div>
    </div>
  );
}
