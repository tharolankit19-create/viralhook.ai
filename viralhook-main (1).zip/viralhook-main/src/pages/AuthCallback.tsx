import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const AuthCallback = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleCallback = async () => {
      try {
        // Get the session from URL hash (Supabase puts tokens in URL fragment)
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (sessionError) {
          console.error("Session error:", sessionError);
          setError(sessionError.message);
          toast({
            title: "Authentication failed",
            description: sessionError.message,
            variant: "destructive",
          });
          setTimeout(() => navigate("/auth", { replace: true }), 2000);
          return;
        }

        if (session?.user) {
          // Successfully authenticated - redirect to dashboard
          navigate("/dashboard", { replace: true });
        } else {
          // No session found, redirect to auth
          navigate("/auth", { replace: true });
        }
      } catch (err) {
        console.error("Callback error:", err);
        setError("An unexpected error occurred");
        setTimeout(() => navigate("/auth", { replace: true }), 2000);
      }
    };

    // Small delay to ensure URL fragment is processed
    const timeout = setTimeout(handleCallback, 100);
    return () => clearTimeout(timeout);
  }, [navigate, toast]);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4">
      {error ? (
        <>
          <p className="text-destructive">{error}</p>
          <p className="text-muted-foreground text-sm">Redirecting to login...</p>
        </>
      ) : (
        <>
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Completing sign in...</p>
        </>
      )}
    </div>
  );
};

export default AuthCallback;
